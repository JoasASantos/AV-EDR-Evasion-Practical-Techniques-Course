#pragma once
// =============================================================================
// EDR Simulator - Telemetry & Alert System
// =============================================================================
// Collects detection events, generates alerts with severity levels,
// and produces final scoring reports for evasion effectiveness measurement.
// =============================================================================

#ifndef EDR_TELEMETRY_HPP
#define EDR_TELEMETRY_HPP

#include <windows.h>
#include <string>
#include <vector>
#include <map>
#include <ctime>
#include <cstdio>
#include <algorithm>
#include "colors.hpp"

namespace EDR {

// Alert severity levels
enum class Severity {
    INFO     = 0,   // Informational, no action needed
    LOW      = 1,   // Minor suspicious activity
    MEDIUM   = 2,   // Moderate suspicious activity
    HIGH     = 3,   // Likely malicious activity
    CRITICAL = 4    // Confirmed malicious activity
};

// Detection categories matching lab exercises
enum class DetectionCategory {
    MEMORY_RWX,             // RWX memory pages
    MEMORY_SHELLCODE,       // Shellcode signatures in memory
    MEMORY_UNBACKED,        // Unbacked executable memory
    NTDLL_HOOK,             // NTDLL function patching/hooking
    ETW_PATCH,              // ETW function patching
    AMSI_PATCH,             // AMSI function patching
    THREAD_SUSPICIOUS,      // Suspicious thread creation
    THREAD_INJECTION,       // Remote thread injection
    MODULE_STOMPING,        // Module .text section overwritten
    MODULE_UNSIGNED,        // Unsigned loaded modules
    SYSCALL_DIRECT,         // Direct syscall instructions
    SYSCALL_STUB,           // Syscall stubs in non-standard locations
    PROCESS_HOLLOW,         // Process hollowing indicators
    APC_INJECTION,          // APC-based injection
    CALLSTACK_SPOOF,        // Spoofed call stacks
    CALLSTACK_UNBACKED,     // Call stack with unbacked addresses
    ANTIDEBUG_PEB,          // Anti-debug via PEB flags
    ANTIDEBUG_TIMING,       // Anti-debug via timing checks
    ANTIDEBUG_HWBP,         // Hardware breakpoint manipulation
    SANDBOX_DETECT,         // Sandbox/VM detection code
    SLEEP_ENCRYPT,          // Sleep obfuscation / memory encryption
    STRING_OBFUSCATION,     // Obfuscated strings detected
    ENCRYPTION_PAYLOAD,     // Encrypted payload in memory
    APPLOCKER_BYPASS,       // AppLocker bypass attempt
    HEAVENS_GATE,           // WoW64 transition (Heaven's Gate)
    BEHAVIOR_SUSPICIOUS,    // General suspicious behavior
};

inline const char* CategoryToString(DetectionCategory cat) {
    switch (cat) {
        case DetectionCategory::MEMORY_RWX:         return "MEMORY:RWX_PAGE";
        case DetectionCategory::MEMORY_SHELLCODE:    return "MEMORY:SHELLCODE";
        case DetectionCategory::MEMORY_UNBACKED:     return "MEMORY:UNBACKED_EXEC";
        case DetectionCategory::NTDLL_HOOK:          return "INTEGRITY:NTDLL_PATCH";
        case DetectionCategory::ETW_PATCH:           return "INTEGRITY:ETW_PATCH";
        case DetectionCategory::AMSI_PATCH:          return "INTEGRITY:AMSI_PATCH";
        case DetectionCategory::THREAD_SUSPICIOUS:   return "THREAD:SUSPICIOUS";
        case DetectionCategory::THREAD_INJECTION:    return "THREAD:INJECTION";
        case DetectionCategory::MODULE_STOMPING:     return "MODULE:STOMPING";
        case DetectionCategory::MODULE_UNSIGNED:     return "MODULE:UNSIGNED";
        case DetectionCategory::SYSCALL_DIRECT:      return "SYSCALL:DIRECT";
        case DetectionCategory::SYSCALL_STUB:        return "SYSCALL:STUB";
        case DetectionCategory::PROCESS_HOLLOW:      return "INJECTION:HOLLOW";
        case DetectionCategory::APC_INJECTION:       return "INJECTION:APC";
        case DetectionCategory::CALLSTACK_SPOOF:     return "STACK:SPOOFED";
        case DetectionCategory::CALLSTACK_UNBACKED:  return "STACK:UNBACKED";
        case DetectionCategory::ANTIDEBUG_PEB:       return "ANTIDEBUG:PEB";
        case DetectionCategory::ANTIDEBUG_TIMING:    return "ANTIDEBUG:TIMING";
        case DetectionCategory::ANTIDEBUG_HWBP:      return "ANTIDEBUG:HWBP";
        case DetectionCategory::SANDBOX_DETECT:      return "SANDBOX:DETECT";
        case DetectionCategory::SLEEP_ENCRYPT:       return "EVASION:SLEEP_CRYPT";
        case DetectionCategory::STRING_OBFUSCATION:  return "EVASION:STRING_OBFS";
        case DetectionCategory::ENCRYPTION_PAYLOAD:  return "EVASION:ENCRYPTED";
        case DetectionCategory::APPLOCKER_BYPASS:    return "POLICY:APPLOCKER";
        case DetectionCategory::HEAVENS_GATE:        return "EVASION:HEAVENS_GATE";
        case DetectionCategory::BEHAVIOR_SUSPICIOUS: return "BEHAVIOR:SUSPICIOUS";
    }
    return "UNKNOWN";
}

inline const char* SeverityToString(Severity sev) {
    switch (sev) {
        case Severity::INFO:     return "INFO";
        case Severity::LOW:      return "LOW";
        case Severity::MEDIUM:   return "MEDIUM";
        case Severity::HIGH:     return "HIGH";
        case Severity::CRITICAL: return "CRITICAL";
    }
    return "UNKNOWN";
}

// Single detection alert
struct Alert {
    Severity          Level;
    DetectionCategory Category;
    std::string       Description;
    std::string       Details;
    uint64_t          Address;      // Memory address if applicable
    DWORD             ThreadId;     // Thread ID if applicable
    time_t            Timestamp;

    Alert() : Level(Severity::INFO), Category(DetectionCategory::BEHAVIOR_SUSPICIOUS),
              Address(0), ThreadId(0), Timestamp(time(nullptr)) {}

    Alert(Severity sev, DetectionCategory cat, const std::string& desc,
          const std::string& detail = "", uint64_t addr = 0, DWORD tid = 0)
        : Level(sev), Category(cat), Description(desc), Details(detail),
          Address(addr), ThreadId(tid), Timestamp(time(nullptr)) {}
};

// Detection module result
struct ModuleResult {
    std::string          ModuleName;
    int                  ChecksRun;
    int                  DetectionsFound;
    std::vector<Alert>   Alerts;
    double               ScanTimeMs;

    ModuleResult(const std::string& name = "")
        : ModuleName(name), ChecksRun(0), DetectionsFound(0), ScanTimeMs(0) {}
};

// Full scan report
class ScanReport {
public:
    std::string              TargetProcess;
    DWORD                    TargetPID;
    std::vector<ModuleResult> ModuleResults;
    time_t                   ScanStart;
    time_t                   ScanEnd;
    bool                     Continuous;
    int                      ScanNumber;

    ScanReport() : TargetPID(0), ScanStart(0), ScanEnd(0),
                   Continuous(false), ScanNumber(0) {}

    int TotalDetections() const {
        int total = 0;
        for (auto& m : ModuleResults) total += m.DetectionsFound;
        return total;
    }

    int TotalChecks() const {
        int total = 0;
        for (auto& m : ModuleResults) total += m.ChecksRun;
        return total;
    }

    int MaxSeverity() const {
        int maxSev = 0;
        for (auto& m : ModuleResults) {
            for (auto& a : m.Alerts) {
                if ((int)a.Level > maxSev) maxSev = (int)a.Level;
            }
        }
        return maxSev;
    }

    // Print formatted report to console
    void Print() const {
        char timeStr[64];
        struct tm tmBuf;
        localtime_s(&tmBuf, &ScanStart);
        strftime(timeStr, sizeof(timeStr), "%Y-%m-%d %H:%M:%S", &tmBuf);

        if (ScanNumber > 0) {
            PrintColored(Color::White, "\n  ═══ Scan #%d ═══ %s ═══\n",
                ScanNumber, timeStr);
        }

        PrintSection("SCAN REPORT");
        char buf[256];
        snprintf(buf, sizeof(buf), "Target: %s (PID: %lu)",
            TargetProcess.c_str(), TargetPID);
        PrintInfo(buf);
        snprintf(buf, sizeof(buf), "Scan Time: %s", timeStr);
        PrintInfo(buf);

        // Print each module's results
        for (auto& mod : ModuleResults) {
            printf("\n");
            PrintSubSection(mod.ModuleName.c_str());

            snprintf(buf, sizeof(buf), "Checks: %d | Detections: %d | Time: %.1fms",
                mod.ChecksRun, mod.DetectionsFound, mod.ScanTimeMs);

            if (mod.DetectionsFound == 0) {
                PrintOK(buf);
            } else {
                PrintWarn(buf);
            }

            // Print alerts
            for (auto& alert : mod.Alerts) {
                snprintf(buf, sizeof(buf), "[%s] [%s] %s",
                    SeverityToString(alert.Level),
                    CategoryToString(alert.Category),
                    alert.Description.c_str());

                switch (alert.Level) {
                    case Severity::CRITICAL:
                        PrintCritical(buf);
                        break;
                    case Severity::HIGH:
                        PrintAlert(buf);
                        break;
                    case Severity::MEDIUM:
                        PrintWarn(buf);
                        break;
                    default:
                        PrintInfo(buf);
                        break;
                }

                if (!alert.Details.empty()) {
                    snprintf(buf, sizeof(buf), "      Detail: %s",
                        alert.Details.c_str());
                    PrintInfo(buf);
                }

                if (alert.Address != 0) {
                    snprintf(buf, sizeof(buf), "      Address: 0x%llX",
                        (unsigned long long)alert.Address);
                    PrintInfo(buf);
                }
            }
        }

        // Print summary
        printf("\n");
        PrintSection("SUMMARY");

        int totalDet = TotalDetections();
        int totalChk = TotalChecks();

        // Category breakdown
        std::map<std::string, int> catCounts;
        for (auto& mod : ModuleResults) {
            for (auto& a : mod.Alerts) {
                catCounts[CategoryToString(a.Category)]++;
            }
        }

        if (!catCounts.empty()) {
            PrintSubSection("Detection Breakdown:");
            for (auto& kv : catCounts) {
                snprintf(buf, sizeof(buf), "  %-30s : %d", kv.first.c_str(), kv.second);
                PrintWarn(buf);
            }
        }

        PrintScore(totalDet, totalChk);
    }

    // Export report to file
    void ExportToFile(const std::string& path) const {
        FILE* f;
        fopen_s(&f, path.c_str(), "w");
        if (!f) return;

        fprintf(f, "EDR Simulator Scan Report\n");
        fprintf(f, "========================\n");
        fprintf(f, "Target: %s (PID: %lu)\n", TargetProcess.c_str(), TargetPID);

        char timeStr[64];
        struct tm tmBuf;
        localtime_s(&tmBuf, &ScanStart);
        strftime(timeStr, sizeof(timeStr), "%Y-%m-%d %H:%M:%S", &tmBuf);
        fprintf(f, "Time: %s\n\n", timeStr);

        for (auto& mod : ModuleResults) {
            fprintf(f, "[%s] Checks: %d | Detections: %d\n",
                mod.ModuleName.c_str(), mod.ChecksRun, mod.DetectionsFound);

            for (auto& alert : mod.Alerts) {
                fprintf(f, "  [%s] [%s] %s\n",
                    SeverityToString(alert.Level),
                    CategoryToString(alert.Category),
                    alert.Description.c_str());
                if (!alert.Details.empty())
                    fprintf(f, "    Detail: %s\n", alert.Details.c_str());
                if (alert.Address)
                    fprintf(f, "    Address: 0x%llX\n", (unsigned long long)alert.Address);
            }
            fprintf(f, "\n");
        }

        int totalDet = TotalDetections();
        int totalChk = TotalChecks();
        float pct = (totalChk > 0) ?
            ((float)(totalChk - totalDet) / totalChk) * 100.0f : 0.0f;

        fprintf(f, "SCORE: %d/%d detections (%.1f%% evasion rate)\n",
            totalDet, totalChk, pct);

        fclose(f);
    }
};

// Telemetry collector - aggregates data across scans
class TelemetryCollector {
public:
    std::vector<ScanReport>  Reports;
    std::vector<Alert>       RealTimeAlerts;
    int                      ScanCount;

    TelemetryCollector() : ScanCount(0) {}

    void AddReport(const ScanReport& report) {
        Reports.push_back(report);
        ScanCount++;
    }

    void AddRealTimeAlert(const Alert& alert) {
        RealTimeAlerts.push_back(alert);
    }

    // Print trend analysis across multiple scans
    void PrintTrend() const {
        if (Reports.size() < 2) return;

        PrintSection("TREND ANALYSIS");

        char buf[256];
        for (size_t i = 0; i < Reports.size(); i++) {
            snprintf(buf, sizeof(buf), "Scan #%d: %d detections / %d checks",
                (int)(i + 1), Reports[i].TotalDetections(), Reports[i].TotalChecks());

            if (i > 0 && Reports[i].TotalDetections() < Reports[i-1].TotalDetections()) {
                PrintOK(buf);
            } else if (i > 0 && Reports[i].TotalDetections() > Reports[i-1].TotalDetections()) {
                PrintAlert(buf);
            } else {
                PrintInfo(buf);
            }
        }
    }
};

} // namespace EDR

#endif // EDR_TELEMETRY_HPP
