#pragma once
// =============================================================================
// EDR Simulator - Console Colors & Formatting
// =============================================================================
// Provides colored terminal output for alerts, reports, and status messages.
// Uses Windows console API for color support.
// =============================================================================

#ifndef EDR_COLORS_HPP
#define EDR_COLORS_HPP

#include <windows.h>
#include <string>
#include <cstdio>

namespace EDR {

enum class Color : WORD {
    Reset   = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE,
    Red     = FOREGROUND_RED | FOREGROUND_INTENSITY,
    Green   = FOREGROUND_GREEN | FOREGROUND_INTENSITY,
    Yellow  = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY,
    Blue    = FOREGROUND_BLUE | FOREGROUND_INTENSITY,
    Cyan    = FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY,
    Magenta = FOREGROUND_RED | FOREGROUND_BLUE | FOREGROUND_INTENSITY,
    White   = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY,
    DarkRed = FOREGROUND_RED,
    DarkGreen = FOREGROUND_GREEN,
    DarkYellow = FOREGROUND_RED | FOREGROUND_GREEN,
    DarkCyan = FOREGROUND_GREEN | FOREGROUND_BLUE,
    BgRed   = BACKGROUND_RED | FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE | FOREGROUND_INTENSITY,
    BgGreen = BACKGROUND_GREEN,
    BgYellow = BACKGROUND_RED | BACKGROUND_GREEN,
};

inline void SetColor(Color c) {
    HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
    SetConsoleTextAttribute(hConsole, static_cast<WORD>(c));
}

inline void ResetColor() {
    SetColor(Color::Reset);
}

inline void PrintColored(Color c, const char* fmt, ...) {
    SetColor(c);
    va_list args;
    va_start(args, fmt);
    vprintf(fmt, args);
    va_end(args);
    ResetColor();
}

inline void PrintBanner() {
    SetColor(Color::Red);
    printf(R"(
  ╔══════════════════════════════════════════════════════════════╗
  ║                                                              ║
  ║   ███████╗██████╗ ██████╗     ███████╗██╗███╗   ███╗         ║
  ║   ██╔════╝██╔══██╗██╔══██╗    ██╔════╝██║████╗ ████║         ║
  ║   █████╗  ██║  ██║██████╔╝    ███████╗██║██╔████╔██║         ║
  ║   ██╔══╝  ██║  ██║██╔══██╗    ╚════██║██║██║╚██╔╝██║         ║
  ║   ███████╗██████╔╝██║  ██║    ███████║██║██║ ╚═╝ ██║         ║
  ║   ╚══════╝╚═════╝ ╚═╝  ╚═╝    ╚══════╝╚═╝╚═╝     ╚═╝         ║
  ║                                                              ║
  ║          Endpoint Detection & Response Simulator             ║
  ║               Evasion Training Platform v2.0                 ║
  ║                                                              ║
  ╚══════════════════════════════════════════════════════════════╝
)");
    ResetColor();
}

inline void PrintSection(const char* title) {
    printf("\n");
    SetColor(Color::Cyan);
    printf("  ┌─────────────────────────────────────────────────────┐\n");
    printf("  │ %-51s │\n", title);
    printf("  └─────────────────────────────────────────────────────┘\n");
    ResetColor();
}

inline void PrintSubSection(const char* title) {
    SetColor(Color::DarkCyan);
    printf("    [*] %s\n", title);
    ResetColor();
}

inline void PrintOK(const char* msg) {
    SetColor(Color::Green);
    printf("    [+] ");
    ResetColor();
    printf("%s\n", msg);
}

inline void PrintWarn(const char* msg) {
    SetColor(Color::Yellow);
    printf("    [!] ");
    ResetColor();
    printf("%s\n", msg);
}

inline void PrintAlert(const char* msg) {
    SetColor(Color::Red);
    printf("    [ALERT] ");
    ResetColor();
    printf("%s\n", msg);
}

inline void PrintCritical(const char* msg) {
    SetColor(Color::BgRed);
    printf("  [CRITICAL] ");
    ResetColor();
    SetColor(Color::Red);
    printf(" %s\n", msg);
    ResetColor();
}

inline void PrintInfo(const char* msg) {
    SetColor(Color::Blue);
    printf("    [i] ");
    ResetColor();
    printf("%s\n", msg);
}

inline void PrintScore(int score, int total) {
    printf("\n");
    SetColor(Color::White);
    printf("  ╔═══════════════════════════════════════╗\n");
    printf("  ║         EVASION SCORE                 ║\n");
    printf("  ╠═══════════════════════════════════════╣\n");

    float pct = (total > 0) ? ((float)(total - score) / total) * 100.0f : 0.0f;
    Color scoreColor = (pct >= 80) ? Color::Green :
                       (pct >= 50) ? Color::Yellow : Color::Red;

    printf("  ║  Detections: ");
    SetColor(scoreColor);
    printf("%-3d / %-3d", score, total);
    SetColor(Color::White);
    printf("              ║\n");

    printf("  ║  Evasion Rate: ");
    SetColor(scoreColor);
    printf("%.1f%%", pct);
    SetColor(Color::White);
    printf("                     ║\n");

    const char* rating;
    if (pct >= 90) rating = "GHOST MODE";
    else if (pct >= 75) rating = "ADVANCED";
    else if (pct >= 50) rating = "INTERMEDIATE";
    else if (pct >= 25) rating = "BEGINNER";
    else rating = "DETECTED";

    printf("  ║  Rating: ");
    SetColor(scoreColor);
    printf("%-28s", rating);
    SetColor(Color::White);
    printf("║\n");

    printf("  ╚═══════════════════════════════════════╝\n");
    ResetColor();
}

inline void PrintProgressBar(const char* label, int current, int total) {
    int barWidth = 30;
    float progress = (total > 0) ? (float)current / total : 0;
    int filled = (int)(barWidth * progress);

    printf("  %-20s [", label);
    for (int i = 0; i < barWidth; i++) {
        if (i < filled) {
            SetColor(Color::Green);
            printf("█");
        } else {
            SetColor(Color::DarkGreen);
            printf("░");
        }
    }
    ResetColor();
    printf("] %d/%d\n", current, total);
}

} // namespace EDR

#endif // EDR_COLORS_HPP
