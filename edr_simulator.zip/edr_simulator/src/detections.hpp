#pragma once
// =============================================================================
// EDR Simulator - Detection Modules
// =============================================================================
// Implements all detection engines that simulate real EDR behavior:
//   1. Memory Scanner       - RWX pages, shellcode signatures, unbacked exec
//   2. NTDLL Integrity      - Hook detection via on-disk comparison
//   3. ETW Monitor          - EtwEventWrite/NtTraceEvent patch detection
//   4. AMSI Monitor         - AmsiScanBuffer/AmsiOpenSession patch detection
//   5. Thread Analyzer      - Suspicious threads, injection detection
//   6. Module Inspector     - Module stomping, unsigned modules
//   7. Syscall Detector     - Direct syscall stubs outside ntdll
//   8. Behavior Monitor     - Process behavior anomalies
//   9. Anti-Debug Detector  - PEB flags, HW breakpoints, timing
//  10. Call Stack Inspector - Stack frame validation
// =============================================================================

#ifndef EDR_DETECTIONS_HPP
#define EDR_DETECTIONS_HPP

#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <dbghelp.h>
#include <winternl.h>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <cstdio>
#include <cstring>
#include <chrono>

#include "telemetry.hpp"
#include "pe_utils.hpp"

#pragma comment(lib, "dbghelp.lib")
#pragma comment(lib, "psapi.lib")
#pragma comment(lib, "ntdll.lib")

namespace EDR {

// ============================================================================
// Shellcode signature patterns for memory scanning
// ============================================================================
struct ShellcodeSignature {
    const char*  Name;
    const uint8_t* Pattern;
    size_t       Length;
    const uint8_t* Mask;   // 0xFF = exact match, 0x00 = wildcard
};

// Common x64 shellcode prologue patterns
static const uint8_t SIG_SYSCALL_STUB[] = {
    0x4C, 0x8B, 0xD1,        // mov r10, rcx
    0xB8                      // mov eax, <SSN>
};
static const uint8_t MASK_SYSCALL_STUB[] = {
    0xFF, 0xFF, 0xFF, 0xFF
};

static const uint8_t SIG_NOP_SLED[] = {
    0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90,
    0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90, 0x90
};
static const uint8_t MASK_NOP_SLED[] = {
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF,
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
};

// Windows API hash pattern (common in shellcode loaders)
static const uint8_t SIG_API_HASH[] = {
    0x65, 0x48, 0x8B, 0x04, 0x25, 0x60, 0x00, 0x00, 0x00  // mov rax, gs:[60h] (PEB access)
};
static const uint8_t MASK_API_HASH[] = {
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
};

// msfvenom x64 exec pattern
static const uint8_t SIG_MSF_EXEC[] = {
    0xFC, 0x48, 0x83, 0xE4, 0xF0   // cld; and rsp, -10h
};
static const uint8_t MASK_MSF_EXEC[] = {
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF
};

// Cobalt Strike beacon patterns
static const uint8_t SIG_CS_BEACON[] = {
    0x4D, 0x5A, 0x41, 0x52, 0x55, 0x48, 0x89, 0xE5  // MZ header + push rbp
};
static const uint8_t MASK_CS_BEACON[] = {
    0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
};

// Hook detection patterns (JMP rel32, JMP [RIP+x])
static const uint8_t SIG_JMP_HOOK[] = { 0xE9 };           // JMP rel32
static const uint8_t SIG_JMP_RIP[] = { 0xFF, 0x25 };      // JMP [RIP+offset]
static const uint8_t SIG_MOV_RAX[] = { 0x48, 0xB8 };      // MOV RAX, imm64

// ETW patch signatures
static const uint8_t SIG_RET_PATCH[] = { 0xC3 };           // RET (single byte)
static const uint8_t SIG_XOR_RET[]   = { 0x33, 0xC0, 0xC3 }; // XOR EAX,EAX; RET

// ============================================================================
// MODULE 1: Memory Scanner
// ============================================================================
class MemoryScanner {
public:
    ModuleResult Scan(HANDLE hProcess, DWORD pid) {
        ModuleResult result("Memory Scanner");
        auto start = std::chrono::high_resolution_clock::now();

        ScanRWXPages(hProcess, result);
        ScanShellcodeSignatures(hProcess, pid, result);
        ScanUnbackedExecutable(hProcess, result);

        auto end = std::chrono::high_resolution_clock::now();
        result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
        return result;
    }

private:
    void ScanRWXPages(HANDLE hProcess, ModuleResult& result) {
        result.ChecksRun++;
        MEMORY_BASIC_INFORMATION mbi;
        uint8_t* addr = nullptr;
        int rwxCount = 0;

        while (VirtualQueryEx(hProcess, addr, &mbi, sizeof(mbi))) {
            if (mbi.State == MEM_COMMIT &&
                mbi.Protect == PAGE_EXECUTE_READWRITE) {

                rwxCount++;
                char detail[256];
                snprintf(detail, sizeof(detail),
                    "RWX page at 0x%p (Size: %zu bytes, Type: %s)",
                    mbi.BaseAddress, mbi.RegionSize,
                    (mbi.Type == MEM_PRIVATE) ? "PRIVATE" :
                    (mbi.Type == MEM_MAPPED) ? "MAPPED" : "IMAGE");

                result.Alerts.push_back(Alert(
                    Severity::HIGH,
                    DetectionCategory::MEMORY_RWX,
                    "Read-Write-Execute memory page detected",
                    detail,
                    (uint64_t)mbi.BaseAddress
                ));
                result.DetectionsFound++;
            }
            addr = (uint8_t*)mbi.BaseAddress + mbi.RegionSize;
        }

        if (rwxCount == 0) {
            // Check for RX pages that were recently RWX (now flipped)
            addr = nullptr;
            while (VirtualQueryEx(hProcess, addr, &mbi, sizeof(mbi))) {
                if (mbi.State == MEM_COMMIT &&
                    mbi.Type == MEM_PRIVATE &&
                    (mbi.Protect == PAGE_EXECUTE_READ ||
                     mbi.Protect == PAGE_EXECUTE)) {

                    // Private executable memory that's not backed by a module
                    // This is suspicious - could be VirtualProtect'd shellcode
                    result.ChecksRun++;

                    char modName[MAX_PATH] = {0};
                    if (GetMappedFileNameA(hProcess, mbi.BaseAddress,
                        modName, MAX_PATH) == 0) {
                        // No mapped file - this is unbacked executable memory
                        char detail[256];
                        snprintf(detail, sizeof(detail),
                            "Private executable memory at 0x%p (%zu bytes) - "
                            "possibly VirtualProtect'd from RWX",
                            mbi.BaseAddress, mbi.RegionSize);

                        result.Alerts.push_back(Alert(
                            Severity::MEDIUM,
                            DetectionCategory::MEMORY_UNBACKED,
                            "Unbacked private executable memory detected",
                            detail,
                            (uint64_t)mbi.BaseAddress
                        ));
                        result.DetectionsFound++;
                    }
                }
                addr = (uint8_t*)mbi.BaseAddress + mbi.RegionSize;
            }
        }
    }

    void ScanShellcodeSignatures(HANDLE hProcess, DWORD pid, ModuleResult& result) {
        result.ChecksRun++;
        MEMORY_BASIC_INFORMATION mbi;
        uint8_t* addr = nullptr;

        // Get list of module base addresses to skip known module code
        std::set<uint64_t> modulePages;
        HMODULE hMods[1024];
        DWORD cbNeeded;
        if (EnumProcessModules(hProcess, hMods, sizeof(hMods), &cbNeeded)) {
            for (unsigned i = 0; i < (cbNeeded / sizeof(HMODULE)); i++) {
                MODULEINFO mi;
                if (GetModuleInformation(hProcess, hMods[i], &mi, sizeof(mi))) {
                    uint64_t base = (uint64_t)mi.lpBaseOfDll;
                    for (uint64_t p = base; p < base + mi.SizeOfImage; p += 0x1000) {
                        modulePages.insert(p & ~0xFFF);
                    }
                }
            }
        }

        while (VirtualQueryEx(hProcess, addr, &mbi, sizeof(mbi))) {
            if (mbi.State == MEM_COMMIT &&
                (mbi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ |
                PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY))) {

                // Skip known module pages
                uint64_t pageBase = (uint64_t)mbi.BaseAddress & ~0xFFF;
                if (modulePages.count(pageBase)) {
                    addr = (uint8_t*)mbi.BaseAddress + mbi.RegionSize;
                    continue;
                }

                // Read the memory region
                size_t regionSize = mbi.RegionSize;
                if (regionSize > 64 * 1024) regionSize = 64 * 1024; // Cap at 64KB

                std::vector<uint8_t> buffer(regionSize);
                SIZE_T bytesRead;
                if (ReadProcessMemory(hProcess, mbi.BaseAddress,
                    buffer.data(), regionSize, &bytesRead)) {

                    // Check each signature
                    CheckSignature(buffer.data(), bytesRead,
                        SIG_MSF_EXEC, MASK_MSF_EXEC, sizeof(SIG_MSF_EXEC),
                        "Metasploit-style shellcode prologue",
                        (uint64_t)mbi.BaseAddress, result);

                    CheckSignature(buffer.data(), bytesRead,
                        SIG_API_HASH, MASK_API_HASH, sizeof(SIG_API_HASH),
                        "PEB access pattern (gs:[60h]) - shellcode API resolution",
                        (uint64_t)mbi.BaseAddress, result);

                    CheckSignature(buffer.data(), bytesRead,
                        SIG_NOP_SLED, MASK_NOP_SLED, sizeof(SIG_NOP_SLED),
                        "NOP sled detected (16+ consecutive NOPs)",
                        (uint64_t)mbi.BaseAddress, result);

                    CheckSignature(buffer.data(), bytesRead,
                        SIG_CS_BEACON, MASK_CS_BEACON, sizeof(SIG_CS_BEACON),
                        "Cobalt Strike beacon-like pattern",
                        (uint64_t)mbi.BaseAddress, result);

                    // Check for syscall stubs outside ntdll
                    CheckSyscallStubs(buffer.data(), bytesRead,
                        (uint64_t)mbi.BaseAddress, result);
                }
            }
            addr = (uint8_t*)mbi.BaseAddress + mbi.RegionSize;
        }
    }

    void ScanUnbackedExecutable(HANDLE hProcess, ModuleResult& result) {
        result.ChecksRun++;
        MEMORY_BASIC_INFORMATION mbi;
        uint8_t* addr = nullptr;
        int unbackedCount = 0;

        while (VirtualQueryEx(hProcess, addr, &mbi, sizeof(mbi))) {
            if (mbi.State == MEM_COMMIT &&
                mbi.Type == MEM_PRIVATE &&
                (mbi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ |
                PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY))) {

                char modName[MAX_PATH] = {0};
                if (GetMappedFileNameA(hProcess, mbi.BaseAddress,
                    modName, MAX_PATH) == 0) {

                    unbackedCount++;
                    if (unbackedCount <= 5) { // Limit alerts
                        char detail[256];
                        snprintf(detail, sizeof(detail),
                            "Unbacked executable at 0x%p (%zu bytes, Prot: 0x%lX)",
                            mbi.BaseAddress, mbi.RegionSize, mbi.Protect);

                        result.Alerts.push_back(Alert(
                            Severity::HIGH,
                            DetectionCategory::MEMORY_UNBACKED,
                            "Executable memory not backed by any file",
                            detail,
                            (uint64_t)mbi.BaseAddress
                        ));
                        result.DetectionsFound++;
                    }
                }
            }
            addr = (uint8_t*)mbi.BaseAddress + mbi.RegionSize;
        }
    }

    void CheckSignature(const uint8_t* data, size_t size,
                        const uint8_t* sig, const uint8_t* mask, size_t sigLen,
                        const char* sigName, uint64_t baseAddr,
                        ModuleResult& result) {
        for (size_t i = 0; i <= size - sigLen; i++) {
            bool match = true;
            for (size_t j = 0; j < sigLen; j++) {
                if ((data[i + j] & mask[j]) != (sig[j] & mask[j])) {
                    match = false;
                    break;
                }
            }
            if (match) {
                char detail[256];
                snprintf(detail, sizeof(detail),
                    "Signature match at offset 0x%zX (absolute: 0x%llX)",
                    i, (unsigned long long)(baseAddr + i));

                result.Alerts.push_back(Alert(
                    Severity::CRITICAL,
                    DetectionCategory::MEMORY_SHELLCODE,
                    sigName,
                    detail,
                    baseAddr + i
                ));
                result.DetectionsFound++;
                return; // One match per signature per region
            }
        }
    }

    void CheckSyscallStubs(const uint8_t* data, size_t size,
                           uint64_t baseAddr, ModuleResult& result) {
        // Look for "mov r10, rcx; mov eax, XX; syscall" pattern
        for (size_t i = 0; i + 12 <= size; i++) {
            if (data[i]   == 0x4C && data[i+1] == 0x8B && data[i+2] == 0xD1 &&  // mov r10, rcx
                data[i+3] == 0xB8) {  // mov eax, imm32
                // Check for syscall instruction nearby
                for (size_t j = i + 7; j < i + 24 && j + 1 < size; j++) {
                    if (data[j] == 0x0F && data[j+1] == 0x05) {  // syscall
                        char detail[256];
                        uint32_t ssn = *(uint32_t*)(data + i + 4);
                        snprintf(detail, sizeof(detail),
                            "Syscall stub (SSN: 0x%X) at 0x%llX - "
                            "direct syscall outside ntdll",
                            ssn, (unsigned long long)(baseAddr + i));

                        result.Alerts.push_back(Alert(
                            Severity::CRITICAL,
                            DetectionCategory::SYSCALL_DIRECT,
                            "Direct syscall stub detected in non-system memory",
                            detail,
                            baseAddr + i
                        ));
                        result.DetectionsFound++;
                        return;
                    }
                }
            }
        }
    }
};

// ============================================================================
// MODULE 2: NTDLL Integrity Checker
// ============================================================================
class NtdllIntegrityChecker {
public:
    ModuleResult Check(HANDLE hProcess) {
        ModuleResult result("NTDLL Integrity Checker");
        auto start = std::chrono::high_resolution_clock::now();

        // Get ntdll path
        char sysDir[MAX_PATH];
        GetSystemDirectoryA(sysDir, MAX_PATH);
        std::string ntdllPath = std::string(sysDir) + "\\ntdll.dll";

        // Read clean ntdll from disk
        auto diskBytes = ReadFileBytes(ntdllPath);
        if (diskBytes.empty()) {
            result.ChecksRun++;
            result.Alerts.push_back(Alert(
                Severity::INFO,
                DetectionCategory::NTDLL_HOOK,
                "Could not read ntdll.dll from disk for comparison"
            ));
            auto end = std::chrono::high_resolution_clock::now();
            result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
            return result;
        }

        auto diskPE = ParsePE(diskBytes.data(), diskBytes.size());
        if (!diskPE.Valid) {
            auto end = std::chrono::high_resolution_clock::now();
            result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
            return result;
        }

        // Find ntdll in target process
        HMODULE hNtdll = nullptr;
        HMODULE hMods[1024];
        DWORD cbNeeded;
        if (EnumProcessModules(hProcess, hMods, sizeof(hMods), &cbNeeded)) {
            for (unsigned i = 0; i < (cbNeeded / sizeof(HMODULE)); i++) {
                char modName[MAX_PATH];
                if (GetModuleFileNameExA(hProcess, hMods[i], modName, MAX_PATH)) {
                    std::string name(modName);
                    // Case insensitive check for ntdll.dll
                    for (auto& c : name) c = (char)tolower(c);
                    if (name.find("ntdll.dll") != std::string::npos) {
                        hNtdll = hMods[i];
                        break;
                    }
                }
            }
        }

        if (!hNtdll) {
            auto end = std::chrono::high_resolution_clock::now();
            result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
            return result;
        }

        // Get .text section info from disk PE
        const uint8_t* diskText;
        uint32_t textSize, textRVA;
        if (!GetTextSection(diskPE, diskBytes.data(), &diskText, &textSize, &textRVA)) {
            auto end = std::chrono::high_resolution_clock::now();
            result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
            return result;
        }

        // Read .text section from process memory
        uint8_t* memTextAddr = (uint8_t*)hNtdll + textRVA;
        std::vector<uint8_t> memText(textSize);
        SIZE_T bytesRead;
        if (!ReadProcessMemory(hProcess, memTextAddr, memText.data(), textSize, &bytesRead)) {
            auto end = std::chrono::high_resolution_clock::now();
            result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
            return result;
        }

        // Compare function prologues for key NT functions
        const char* criticalFuncs[] = {
            "NtAllocateVirtualMemory",
            "NtProtectVirtualMemory",
            "NtWriteVirtualMemory",
            "NtCreateThreadEx",
            "NtCreateSection",
            "NtMapViewOfSection",
            "NtQueueApcThread",
            "NtSetContextThread",
            "NtResumeThread",
            "NtOpenProcess",
            "NtCreateProcess",
            "NtReadVirtualMemory",
            "NtFreeVirtualMemory",
            "NtQueryInformationProcess",
            "NtCreateFile",
            "NtWriteFile",
            nullptr
        };

        for (int i = 0; criticalFuncs[i]; i++) {
            result.ChecksRun++;

            auto* exp = FindExport(diskPE, criticalFuncs[i]);
            if (!exp) continue;

            // Get offset within .text
            if (exp->RVA < textRVA || exp->RVA >= textRVA + textSize) continue;
            uint32_t funcOffset = exp->RVA - textRVA;

            // Compare first 16 bytes (function prologue)
            size_t cmpSize = 16;
            if (funcOffset + cmpSize > textSize) continue;

            uint32_t diskFuncOffset = RvaToOffset(diskPE, exp->RVA);
            if (diskFuncOffset + cmpSize > diskBytes.size()) continue;

            const uint8_t* diskFunc = diskBytes.data() + diskFuncOffset;
            const uint8_t* memFunc  = memText.data() + funcOffset;

            if (memcmp(diskFunc, memFunc, cmpSize) != 0) {
                // Detected modification!
                char detail[512];
                char diskHex[64] = {0}, memHex[64] = {0};

                for (size_t b = 0; b < 8; b++) {
                    snprintf(diskHex + b*3, 4, "%02X ", diskFunc[b]);
                    snprintf(memHex + b*3, 4, "%02X ", memFunc[b]);
                }

                snprintf(detail, sizeof(detail),
                    "%s patched! Disk: [%s] Memory: [%s]",
                    criticalFuncs[i], diskHex, memHex);

                // Determine hook type
                Severity sev = Severity::CRITICAL;
                const char* hookType = "Unknown hook";

                if (memFunc[0] == 0xE9) hookType = "JMP rel32 hook (inline)";
                else if (memFunc[0] == 0xFF && memFunc[1] == 0x25) hookType = "JMP [RIP+offset] hook";
                else if (memFunc[0] == 0x48 && memFunc[1] == 0xB8) hookType = "MOV RAX, imm64 hook";
                else if (memFunc[0] == 0xC3) hookType = "RET patch (function disabled)";
                else if (memFunc[0] == 0x33 && memFunc[1] == 0xC0 && memFunc[2] == 0xC3)
                    hookType = "XOR EAX,EAX; RET (return success)";

                char hookDetail[768];
                snprintf(hookDetail, sizeof(hookDetail), "%s - Hook type: %s", detail, hookType);

                result.Alerts.push_back(Alert(
                    sev,
                    DetectionCategory::NTDLL_HOOK,
                    std::string("NTDLL function hooked: ") + criticalFuncs[i],
                    hookDetail,
                    (uint64_t)memTextAddr + funcOffset
                ));
                result.DetectionsFound++;
            }
        }

        // Full .text section diff (summary)
        result.ChecksRun++;
        int patchedBytes = 0;
        size_t compareSize = (bytesRead < textSize) ? bytesRead : textSize;
        uint32_t diskTextFileOffset = 0;
        for (auto& sec : diskPE.Sections) {
            if (strcmp(sec.Name, ".text") == 0) {
                diskTextFileOffset = sec.RawOffset;
                break;
            }
        }

        if (diskTextFileOffset > 0 && diskTextFileOffset + compareSize <= diskBytes.size()) {
            for (size_t i = 0; i < compareSize; i++) {
                if (memText[i] != diskBytes[diskTextFileOffset + i]) patchedBytes++;
            }
        }

        if (patchedBytes > 0) {
            char detail[256];
            snprintf(detail, sizeof(detail),
                "%d bytes differ in .text section (%zu bytes total, %.2f%% modified)",
                patchedBytes, compareSize, (float)patchedBytes / compareSize * 100);

            result.Alerts.push_back(Alert(
                (patchedBytes > 100) ? Severity::CRITICAL : Severity::HIGH,
                DetectionCategory::NTDLL_HOOK,
                "NTDLL .text section integrity violation",
                detail
            ));
            result.DetectionsFound++;
        }

        auto end = std::chrono::high_resolution_clock::now();
        result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
        return result;
    }
};

// ============================================================================
// MODULE 3: ETW Monitor
// ============================================================================
class EtwMonitor {
public:
    ModuleResult Check(HANDLE hProcess) {
        ModuleResult result("ETW Monitor");
        auto start = std::chrono::high_resolution_clock::now();

        // Check EtwEventWrite
        CheckFunctionIntegrity(hProcess, "ntdll.dll", "EtwEventWrite",
            DetectionCategory::ETW_PATCH, result);

        // Check EtwEventRegister
        CheckFunctionIntegrity(hProcess, "ntdll.dll", "EtwEventRegister",
            DetectionCategory::ETW_PATCH, result);

        // Check NtTraceEvent
        CheckFunctionIntegrity(hProcess, "ntdll.dll", "NtTraceEvent",
            DetectionCategory::ETW_PATCH, result);

        // Check NtTraceControl
        CheckFunctionIntegrity(hProcess, "ntdll.dll", "NtTraceControl",
            DetectionCategory::ETW_PATCH, result);

        auto end = std::chrono::high_resolution_clock::now();
        result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
        return result;
    }

private:
    void CheckFunctionIntegrity(HANDLE hProcess, const char* moduleName,
                                 const char* funcName, DetectionCategory cat,
                                 ModuleResult& result) {
        result.ChecksRun++;

        // Get system directory for clean copy
        char sysDir[MAX_PATH];
        GetSystemDirectoryA(sysDir, MAX_PATH);
        std::string dllPath = std::string(sysDir) + "\\" + moduleName;

        auto diskBytes = ReadFileBytes(dllPath);
        if (diskBytes.empty()) return;

        auto diskPE = ParsePE(diskBytes.data(), diskBytes.size());
        if (!diskPE.Valid) return;

        auto* exp = FindExport(diskPE, funcName);
        if (!exp) return;

        // Find module in target process
        HMODULE hMod = nullptr;
        HMODULE hMods[1024];
        DWORD cbNeeded;
        if (EnumProcessModules(hProcess, hMods, sizeof(hMods), &cbNeeded)) {
            for (unsigned i = 0; i < (cbNeeded / sizeof(HMODULE)); i++) {
                char modPath[MAX_PATH];
                if (GetModuleFileNameExA(hProcess, hMods[i], modPath, MAX_PATH)) {
                    std::string name(modPath);
                    for (auto& c : name) c = (char)tolower(c);
                    if (name.find(moduleName) != std::string::npos) {
                        hMod = hMods[i];
                        break;
                    }
                }
            }
        }
        if (!hMod) return;

        // Read function bytes from memory
        uint8_t memBytes[32];
        SIZE_T bytesRead;
        void* funcAddr = (uint8_t*)hMod + exp->RVA;
        if (!ReadProcessMemory(hProcess, funcAddr, memBytes, sizeof(memBytes), &bytesRead))
            return;

        // Read function bytes from disk
        uint32_t diskOffset = RvaToOffset(diskPE, exp->RVA);
        if (diskOffset == 0 || diskOffset + 32 > diskBytes.size()) return;
        const uint8_t* diskFunc = diskBytes.data() + diskOffset;

        // Compare
        if (memcmp(diskFunc, memBytes, 16) != 0) {
            char detail[512];
            char diskHex[64] = {0}, memHex[64] = {0};
            for (int b = 0; b < 8; b++) {
                snprintf(diskHex + b*3, 4, "%02X ", diskFunc[b]);
                snprintf(memHex + b*3, 4, "%02X ", memBytes[b]);
            }

            // Identify patch type
            const char* patchType = "Modified";
            if (memBytes[0] == 0xC3) patchType = "RET (function disabled)";
            else if (memBytes[0] == 0x33 && memBytes[1] == 0xC0 && memBytes[2] == 0xC3)
                patchType = "XOR EAX,EAX; RET (returns success, no-op)";
            else if (memBytes[0] == 0xE9) patchType = "JMP hook (redirected)";
            else if (memBytes[0] == 0x48 && memBytes[1] == 0x31 && memBytes[2] == 0xC0)
                patchType = "XOR RAX,RAX; ... (zeroed return)";

            snprintf(detail, sizeof(detail),
                "%s patched: %s | Disk: [%s] Mem: [%s]",
                funcName, patchType, diskHex, memHex);

            result.Alerts.push_back(Alert(
                Severity::CRITICAL, cat,
                std::string("ETW function patched: ") + funcName,
                detail,
                (uint64_t)funcAddr
            ));
            result.DetectionsFound++;
        }
    }
};

// ============================================================================
// MODULE 4: AMSI Monitor
// ============================================================================
class AmsiMonitor {
public:
    ModuleResult Check(HANDLE hProcess) {
        ModuleResult result("AMSI Monitor");
        auto start = std::chrono::high_resolution_clock::now();

        // Check if amsi.dll is loaded
        HMODULE hAmsi = nullptr;
        HMODULE hMods[1024];
        DWORD cbNeeded;
        bool amsiLoaded = false;

        if (EnumProcessModules(hProcess, hMods, sizeof(hMods), &cbNeeded)) {
            for (unsigned i = 0; i < (cbNeeded / sizeof(HMODULE)); i++) {
                char modPath[MAX_PATH];
                if (GetModuleFileNameExA(hProcess, hMods[i], modPath, MAX_PATH)) {
                    std::string name(modPath);
                    for (auto& c : name) c = (char)tolower(c);
                    if (name.find("amsi.dll") != std::string::npos) {
                        hAmsi = hMods[i];
                        amsiLoaded = true;
                        break;
                    }
                }
            }
        }

        result.ChecksRun++;
        if (!amsiLoaded) {
            // AMSI not loaded - this might be fine for non-.NET processes
            auto end = std::chrono::high_resolution_clock::now();
            result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
            return result;
        }

        // Check AmsiScanBuffer integrity
        CheckAmsiFunction(hProcess, hAmsi, "AmsiScanBuffer", result);
        CheckAmsiFunction(hProcess, hAmsi, "AmsiOpenSession", result);
        CheckAmsiFunction(hProcess, hAmsi, "AmsiScanString", result);

        // Check for AmsiInitFailed flag manipulation
        CheckAmsiContext(hProcess, hAmsi, result);

        auto end = std::chrono::high_resolution_clock::now();
        result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
        return result;
    }

private:
    void CheckAmsiFunction(HANDLE hProcess, HMODULE hAmsi,
                           const char* funcName, ModuleResult& result) {
        result.ChecksRun++;

        char sysDir[MAX_PATH];
        GetSystemDirectoryA(sysDir, MAX_PATH);
        std::string amsiPath = std::string(sysDir) + "\\amsi.dll";

        auto diskBytes = ReadFileBytes(amsiPath);
        if (diskBytes.empty()) return;

        auto diskPE = ParsePE(diskBytes.data(), diskBytes.size());
        if (!diskPE.Valid) return;

        auto* exp = FindExport(diskPE, funcName);
        if (!exp) return;

        // Read from process
        uint8_t memBytes[32];
        SIZE_T bytesRead;
        void* funcAddr = (uint8_t*)hAmsi + exp->RVA;
        if (!ReadProcessMemory(hProcess, funcAddr, memBytes, sizeof(memBytes), &bytesRead))
            return;

        // Read from disk
        uint32_t diskOffset = RvaToOffset(diskPE, exp->RVA);
        if (diskOffset == 0 || diskOffset + 32 > diskBytes.size()) return;
        const uint8_t* diskFunc = diskBytes.data() + diskOffset;

        if (memcmp(diskFunc, memBytes, 16) != 0) {
            char detail[512];
            char memHex[64] = {0};
            for (int b = 0; b < 8; b++) {
                snprintf(memHex + b*3, 4, "%02X ", memBytes[b]);
            }

            const char* patchType = "Modified";
            if (memBytes[0] == 0xB8 && memBytes[5] == 0xC3)
                patchType = "MOV EAX, imm32; RET (forced return value)";
            else if (memBytes[0] == 0xC3)
                patchType = "RET (function disabled)";
            else if (memBytes[0] == 0x33 && memBytes[1] == 0xC0 && memBytes[2] == 0xC3)
                patchType = "XOR EAX,EAX; RET (returns S_OK)";
            else if (memBytes[0] == 0xE9)
                patchType = "JMP hook (redirected)";

            snprintf(detail, sizeof(detail),
                "%s patch: %s | Bytes: [%s]", funcName, patchType, memHex);

            result.Alerts.push_back(Alert(
                Severity::CRITICAL,
                DetectionCategory::AMSI_PATCH,
                std::string("AMSI function patched: ") + funcName,
                detail,
                (uint64_t)funcAddr
            ));
            result.DetectionsFound++;
        }
    }

    void CheckAmsiContext(HANDLE hProcess, HMODULE hAmsi, ModuleResult& result) {
        result.ChecksRun++;
        // Check .data section for AmsiInitFailed flag manipulation
        // The flag is in the .data section of amsi.dll
        char sysDir[MAX_PATH];
        GetSystemDirectoryA(sysDir, MAX_PATH);
        std::string amsiPath = std::string(sysDir) + "\\amsi.dll";

        auto diskBytes = ReadFileBytes(amsiPath);
        if (diskBytes.empty()) return;

        auto diskPE = ParsePE(diskBytes.data(), diskBytes.size());
        if (!diskPE.Valid) return;

        // Find .data section
        for (auto& sec : diskPE.Sections) {
            if (strcmp(sec.Name, ".data") == 0) {
                std::vector<uint8_t> diskData(sec.RawSize);
                if (sec.RawOffset + sec.RawSize <= diskBytes.size()) {
                    memcpy(diskData.data(), diskBytes.data() + sec.RawOffset, sec.RawSize);
                }

                std::vector<uint8_t> memData(sec.VirtualSize);
                SIZE_T bytesRead;
                void* dataAddr = (uint8_t*)hAmsi + sec.VirtualAddress;
                if (ReadProcessMemory(hProcess, dataAddr, memData.data(),
                    sec.VirtualSize, &bytesRead)) {

                    size_t cmpSize = min(sec.RawSize, (uint32_t)bytesRead);
                    if (memcmp(diskData.data(), memData.data(), cmpSize) != 0) {
                        result.Alerts.push_back(Alert(
                            Severity::HIGH,
                            DetectionCategory::AMSI_PATCH,
                            "AMSI .data section modified (possible AmsiInitFailed manipulation)",
                            "The .data section of amsi.dll has been modified in memory",
                            (uint64_t)dataAddr
                        ));
                        result.DetectionsFound++;
                    }
                }
                break;
            }
        }
    }
};

// ============================================================================
// MODULE 5: Thread Analyzer
// ============================================================================
class ThreadAnalyzer {
public:
    ModuleResult Analyze(HANDLE hProcess, DWORD targetPid) {
        ModuleResult result("Thread Analyzer");
        auto start = std::chrono::high_resolution_clock::now();

        // Get module info for validating thread start addresses
        std::vector<std::pair<uint64_t, uint64_t>> moduleRanges; // base, end
        std::map<uint64_t, std::string> moduleNames;

        HMODULE hMods[1024];
        DWORD cbNeeded;
        if (EnumProcessModules(hProcess, hMods, sizeof(hMods), &cbNeeded)) {
            for (unsigned i = 0; i < (cbNeeded / sizeof(HMODULE)); i++) {
                MODULEINFO mi;
                char modName[MAX_PATH];
                if (GetModuleInformation(hProcess, hMods[i], &mi, sizeof(mi)) &&
                    GetModuleFileNameExA(hProcess, hMods[i], modName, MAX_PATH)) {

                    uint64_t base = (uint64_t)mi.lpBaseOfDll;
                    uint64_t end  = base + mi.SizeOfImage;
                    moduleRanges.push_back({base, end});
                    moduleNames[base] = modName;
                }
            }
        }

        // If module enumeration failed, skip thread start address validation
        // to avoid false positives (every thread would appear unbacked)
        bool canValidateStartAddr = !moduleRanges.empty();

        // Enumerate threads
        HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
        if (hSnap == INVALID_HANDLE_VALUE) {
            auto end = std::chrono::high_resolution_clock::now();
            result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
            return result;
        }

        THREADENTRY32 te;
        te.dwSize = sizeof(te);
        if (Thread32First(hSnap, &te)) {
            do {
                if (te.th32OwnerProcessID != targetPid) continue;

                HANDLE hThread = OpenThread(
                    THREAD_QUERY_INFORMATION | THREAD_GET_CONTEXT,
                    FALSE, te.th32ThreadID);
                if (!hThread) continue;

                // Get thread start address (only validate if we have module info)
                if (canValidateStartAddr) {
                    result.ChecksRun++;

                    typedef NTSTATUS (WINAPI *pNtQIT)(HANDLE, LONG, PVOID, ULONG, PULONG);
                    static auto NtQueryInformationThread = (pNtQIT)GetProcAddress(
                        GetModuleHandleA("ntdll.dll"), "NtQueryInformationThread");

                    if (NtQueryInformationThread) {
                        PVOID startAddr = nullptr;
                        ULONG retLen;
                        // ThreadQuerySetWin32StartAddress = 9
                        if (NtQueryInformationThread(hThread, (THREADINFOCLASS)9,
                            &startAddr, sizeof(startAddr), &retLen) == 0) {

                            uint64_t addr = (uint64_t)startAddr;

                            // Check if start address is within a known module
                            bool inModule = false;
                            std::string moduleName;
                            for (auto& range : moduleRanges) {
                                if (addr >= range.first && addr < range.second) {
                                    inModule = true;
                                    moduleName = moduleNames[range.first];
                                    break;
                                }
                            }

                            if (!inModule && addr != 0) {
                                char detail[256];
                                snprintf(detail, sizeof(detail),
                                    "Thread %lu start address 0x%llX is not backed by any module",
                                    te.th32ThreadID, (unsigned long long)addr);

                                result.Alerts.push_back(Alert(
                                    Severity::CRITICAL,
                                    DetectionCategory::THREAD_SUSPICIOUS,
                                    "Thread with unbacked start address detected",
                                    detail,
                                    addr,
                                    te.th32ThreadID
                                ));
                                result.DetectionsFound++;
                            }
                        }
                    }
                }

                // Check thread context for suspicious state
                CONTEXT ctx = {};
                ctx.ContextFlags = CONTEXT_ALL;
                if (GetThreadContext(hThread, &ctx)) {
                    result.ChecksRun++;

                    // Check for hardware breakpoints (anti-debug technique)
                    if (ctx.Dr0 || ctx.Dr1 || ctx.Dr2 || ctx.Dr3) {
                        char detail[256];
                        snprintf(detail, sizeof(detail),
                            "Thread %lu has hardware breakpoints: DR0=0x%llX DR1=0x%llX DR2=0x%llX DR3=0x%llX",
                            te.th32ThreadID,
                            (unsigned long long)ctx.Dr0, (unsigned long long)ctx.Dr1,
                            (unsigned long long)ctx.Dr2, (unsigned long long)ctx.Dr3);

                        result.Alerts.push_back(Alert(
                            Severity::MEDIUM,
                            DetectionCategory::ANTIDEBUG_HWBP,
                            "Hardware breakpoints set (possible anti-debug or hook mechanism)",
                            detail,
                            0, te.th32ThreadID
                        ));
                        result.DetectionsFound++;
                    }
                }

                CloseHandle(hThread);
            } while (Thread32Next(hSnap, &te));
        }
        CloseHandle(hSnap);

        auto end = std::chrono::high_resolution_clock::now();
        result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
        return result;
    }
};

// ============================================================================
// MODULE 6: Module Inspector
// ============================================================================
class ModuleInspector {
public:
    ModuleResult Inspect(HANDLE hProcess) {
        ModuleResult result("Module Inspector");
        auto start = std::chrono::high_resolution_clock::now();

        HMODULE hMods[1024];
        DWORD cbNeeded;
        if (!EnumProcessModules(hProcess, hMods, sizeof(hMods), &cbNeeded)) {
            auto end = std::chrono::high_resolution_clock::now();
            result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
            return result;
        }

        for (unsigned i = 0; i < (cbNeeded / sizeof(HMODULE)); i++) {
            char modPath[MAX_PATH];
            if (!GetModuleFileNameExA(hProcess, hMods[i], modPath, MAX_PATH)) continue;

            MODULEINFO mi;
            if (!GetModuleInformation(hProcess, hMods[i], &mi, sizeof(mi))) continue;

            // Check for module stomping
            CheckModuleStomping(hProcess, hMods[i], modPath, mi, result);
        }

        auto end = std::chrono::high_resolution_clock::now();
        result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
        return result;
    }

private:
    void CheckModuleStomping(HANDLE hProcess, HMODULE hMod,
                              const char* modPath, MODULEINFO& mi,
                              ModuleResult& result) {
        result.ChecksRun++;

        // Read the on-disk version
        auto diskBytes = ReadFileBytes(modPath);
        if (diskBytes.empty()) return;

        auto diskPE = ParsePE(diskBytes.data(), diskBytes.size());
        if (!diskPE.Valid) return;

        // Compare .text section
        for (auto& sec : diskPE.Sections) {
            if (strcmp(sec.Name, ".text") != 0) continue;

            // Read section from disk
            if (sec.RawOffset + sec.RawSize > diskBytes.size()) continue;
            const uint8_t* diskText = diskBytes.data() + sec.RawOffset;

            // Read section from memory
            std::vector<uint8_t> memText(sec.VirtualSize);
            SIZE_T bytesRead;
            void* memAddr = (uint8_t*)hMod + sec.VirtualAddress;

            if (!ReadProcessMemory(hProcess, memAddr, memText.data(),
                sec.VirtualSize, &bytesRead)) continue;

            // Skip ntdll and other system DLLs (handled by NTDLL checker)
            std::string path(modPath);
            for (auto& c : path) c = (char)tolower(c);
            if (path.find("ntdll.dll") != std::string::npos) continue;
            if (path.find("amsi.dll") != std::string::npos) continue;

            // Compare
            size_t cmpSize = min(sec.RawSize, (uint32_t)bytesRead);
            int diffBytes = 0;
            for (size_t j = 0; j < cmpSize; j++) {
                if (diskText[j] != memText[j]) diffBytes++;
            }

            // If significant portion is different, it's likely module stomping
            if (diffBytes > 0) {
                float diffPct = (float)diffBytes / cmpSize * 100;

                if (diffPct > 10.0f) {
                    char detail[512];
                    snprintf(detail, sizeof(detail),
                        "%s .text section: %d/%zu bytes differ (%.1f%%) - "
                        "likely module stomping",
                        modPath, diffBytes, cmpSize, diffPct);

                    result.Alerts.push_back(Alert(
                        Severity::CRITICAL,
                        DetectionCategory::MODULE_STOMPING,
                        "Module stomping detected - .text section overwritten",
                        detail,
                        (uint64_t)memAddr
                    ));
                    result.DetectionsFound++;
                } else if (diffPct > 1.0f) {
                    char detail[512];
                    snprintf(detail, sizeof(detail),
                        "%s .text section: %d/%zu bytes differ (%.1f%%)",
                        modPath, diffBytes, cmpSize, diffPct);

                    result.Alerts.push_back(Alert(
                        Severity::MEDIUM,
                        DetectionCategory::MODULE_STOMPING,
                        "Module .text section partially modified",
                        detail,
                        (uint64_t)memAddr
                    ));
                    result.DetectionsFound++;
                }
            }
            break; // Only check .text
        }
    }
};

// ============================================================================
// MODULE 7: Syscall Detector
// ============================================================================
class SyscallDetector {
public:
    ModuleResult Detect(HANDLE hProcess) {
        ModuleResult result("Syscall Detector");
        auto start = std::chrono::high_resolution_clock::now();

        // Get ntdll address range
        HMODULE hNtdll = nullptr;
        MODULEINFO ntdllInfo = {};
        HMODULE hMods[1024];
        DWORD cbNeeded;

        if (EnumProcessModules(hProcess, hMods, sizeof(hMods), &cbNeeded)) {
            for (unsigned i = 0; i < (cbNeeded / sizeof(HMODULE)); i++) {
                char modName[MAX_PATH];
                if (GetModuleFileNameExA(hProcess, hMods[i], modName, MAX_PATH)) {
                    std::string name(modName);
                    for (auto& c : name) c = (char)tolower(c);
                    if (name.find("ntdll.dll") != std::string::npos) {
                        hNtdll = hMods[i];
                        GetModuleInformation(hProcess, hMods[i], &ntdllInfo, sizeof(ntdllInfo));
                        break;
                    }
                }
            }
        }

        uint64_t ntdllBase = (uint64_t)ntdllInfo.lpBaseOfDll;
        uint64_t ntdllEnd  = ntdllBase + ntdllInfo.SizeOfImage;

        // Scan all executable memory for syscall instructions
        MEMORY_BASIC_INFORMATION mbi;
        uint8_t* addr = nullptr;

        while (VirtualQueryEx(hProcess, addr, &mbi, sizeof(mbi))) {
            if (mbi.State == MEM_COMMIT &&
                (mbi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ |
                PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY))) {

                uint64_t regionBase = (uint64_t)mbi.BaseAddress;
                uint64_t regionEnd  = regionBase + mbi.RegionSize;

                // Skip ntdll itself
                if (regionBase >= ntdllBase && regionEnd <= ntdllEnd) {
                    addr = (uint8_t*)mbi.BaseAddress + mbi.RegionSize;
                    continue;
                }

                // Resolve backing module for this memory region
                char modName[MAX_PATH] = {0};
                GetMappedFileNameA(hProcess, mbi.BaseAddress, modName, MAX_PATH);
                std::string modStr(modName);
                for (auto& c : modStr) c = (char)tolower(c);

                // Skip ntdll and win32u (legitimate syscall sources)
                if (modStr.find("win32u") != std::string::npos ||
                    modStr.find("ntdll") != std::string::npos) {
                    addr = (uint8_t*)mbi.BaseAddress + mbi.RegionSize;
                    continue;
                }

                // Skip known Windows system modules - they legitimately
                // contain 0F 05 bytes (compat stubs, internal optimizations).
                // Real EDRs focus on anomalous regions, not Microsoft binaries.
                if (!modStr.empty()) {
                    if (modStr.find("\\windows\\system32\\") != std::string::npos ||
                        modStr.find("\\windows\\syswow64\\") != std::string::npos ||
                        modStr.find("\\windows\\winsxs\\") != std::string::npos ||
                        modStr.find("\\windows\\microsoft.net\\") != std::string::npos) {
                        addr = (uint8_t*)mbi.BaseAddress + mbi.RegionSize;
                        continue;
                    }
                }

                // Read and scan
                size_t scanSize = mbi.RegionSize;
                if (scanSize > 128 * 1024) scanSize = 128 * 1024;

                std::vector<uint8_t> buffer(scanSize);
                SIZE_T bytesRead;
                if (ReadProcessMemory(hProcess, mbi.BaseAddress,
                    buffer.data(), scanSize, &bytesRead)) {

                    result.ChecksRun++;  // Count each scanned region

                    for (size_t j = 0; j + 1 < bytesRead; j++) {
                        // syscall = 0F 05
                        if (buffer[j] == 0x0F && buffer[j+1] == 0x05) {
                            // Check if this looks like a syscall stub
                            // Look backwards for mov r10, rcx pattern
                            bool isSyscallStub = false;
                            if (j >= 7) {
                                for (int k = 1; k <= 12 && (int)j - k >= 0; k++) {
                                    size_t checkPos = j - k;
                                    if (checkPos + 2 < bytesRead &&
                                        buffer[checkPos] == 0x4C &&
                                        buffer[checkPos+1] == 0x8B &&
                                        buffer[checkPos+2] == 0xD1) {
                                        isSyscallStub = true;
                                        break;
                                    }
                                }
                            }

                            bool isUnbacked = modStr.empty();

                            char detail[512];
                            snprintf(detail, sizeof(detail),
                                "syscall instruction at 0x%llX (%s) %s",
                                (unsigned long long)(regionBase + j),
                                isUnbacked ? "UNBACKED MEMORY" : modStr.c_str(),
                                isSyscallStub ? "- matches syscall stub pattern" : "");

                            result.Alerts.push_back(Alert(
                                isSyscallStub ? Severity::CRITICAL : Severity::HIGH,
                                isSyscallStub ? DetectionCategory::SYSCALL_STUB :
                                    DetectionCategory::SYSCALL_DIRECT,
                                isUnbacked ?
                                    "Direct syscall instruction in unbacked memory" :
                                    "Direct syscall instruction in non-system module",
                                detail,
                                regionBase + j
                            ));
                            result.DetectionsFound++;

                            j += 2; // Skip past this syscall
                            if (result.DetectionsFound >= 10) break; // Limit per-region
                        }
                    }
                }
            }
            addr = (uint8_t*)mbi.BaseAddress + mbi.RegionSize;
            if (result.DetectionsFound >= 10) break;  // Global limit
        }

        // Ensure at least 1 check is counted even if no regions were scanned
        if (result.ChecksRun == 0) result.ChecksRun = 1;

        auto end = std::chrono::high_resolution_clock::now();
        result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
        return result;
    }
};

// ============================================================================
// MODULE 8: Behavior Monitor
// ============================================================================
class BehaviorMonitor {
public:
    ModuleResult Monitor(HANDLE hProcess, DWORD targetPid) {
        ModuleResult result("Behavior Monitor");
        auto start = std::chrono::high_resolution_clock::now();

        // Check for cross-process handles
        CheckCrossProcessHandles(hProcess, targetPid, result);

        // Check process token privileges
        CheckTokenPrivileges(hProcess, result);

        // Check for child processes
        CheckChildProcesses(targetPid, result);

        auto end = std::chrono::high_resolution_clock::now();
        result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
        return result;
    }

private:
    void CheckCrossProcessHandles(HANDLE hProcess, DWORD targetPid, ModuleResult& result) {
        result.ChecksRun++;
        // This would need NtQuerySystemInformation with SystemHandleInformation
        // Simplified: check if process has handles to other processes
        // For the simulator, we'll check if the target has typical injection handles
    }

    void CheckTokenPrivileges(HANDLE hProcess, ModuleResult& result) {
        result.ChecksRun++;
        HANDLE hToken;
        if (OpenProcessToken(hProcess, TOKEN_QUERY, &hToken)) {
            TOKEN_ELEVATION elevation;
            DWORD size;
            if (GetTokenInformation(hToken, TokenElevation, &elevation,
                sizeof(elevation), &size)) {
                if (elevation.TokenIsElevated) {
                    result.Alerts.push_back(Alert(
                        Severity::LOW,
                        DetectionCategory::BEHAVIOR_SUSPICIOUS,
                        "Process is running with elevated privileges",
                        "Elevated processes have more capability for evasion"
                    ));
                    result.DetectionsFound++;
                }
            }
            CloseHandle(hToken);
        }
    }

    void CheckChildProcesses(DWORD targetPid, ModuleResult& result) {
        result.ChecksRun++;
        HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hSnap == INVALID_HANDLE_VALUE) return;

        PROCESSENTRY32 pe;
        pe.dwSize = sizeof(pe);
        int childCount = 0;

        if (Process32First(hSnap, &pe)) {
            do {
                if (pe.th32ParentProcessID == targetPid) {
                    childCount++;
                    char detail[256];
#ifdef UNICODE
                    char childName[MAX_PATH];
                    wcstombs(childName, pe.szExeFile, MAX_PATH);
                    snprintf(detail, sizeof(detail),
                        "Child process: %s (PID: %lu)",
                        childName, pe.th32ProcessID);
#else
                    snprintf(detail, sizeof(detail),
                        "Child process: %s (PID: %lu)",
                        pe.szExeFile, pe.th32ProcessID);
#endif

                    result.Alerts.push_back(Alert(
                        Severity::MEDIUM,
                        DetectionCategory::BEHAVIOR_SUSPICIOUS,
                        "Suspicious child process spawned",
                        detail,
                        0, pe.th32ProcessID
                    ));
                    result.DetectionsFound++;
                }
            } while (Process32Next(hSnap, &pe));
        }
        CloseHandle(hSnap);
    }
};

// ============================================================================
// MODULE 9: Anti-Debug Detector
// ============================================================================
class AntiDebugDetector {
public:
    ModuleResult Detect(HANDLE hProcess, DWORD targetPid) {
        ModuleResult result("Anti-Debug Detector");
        auto start = std::chrono::high_resolution_clock::now();

        CheckPEBDebugFlags(hProcess, result);
        CheckNtGlobalFlag(hProcess, result);
        CheckHeapFlags(hProcess, result);

        auto end = std::chrono::high_resolution_clock::now();
        result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
        return result;
    }

private:
    void CheckPEBDebugFlags(HANDLE hProcess, ModuleResult& result) {
        result.ChecksRun++;

        // Use NtQueryInformationProcess to get PEB address
        typedef NTSTATUS (WINAPI *pNtQIP)(HANDLE, PROCESSINFOCLASS, PVOID, ULONG, PULONG);
        static auto NtQueryInformationProcess = (pNtQIP)GetProcAddress(
            GetModuleHandleA("ntdll.dll"), "NtQueryInformationProcess");

        if (!NtQueryInformationProcess) return;

        PROCESS_BASIC_INFORMATION pbi = {};
        ULONG retLen;
        if (NtQueryInformationProcess(hProcess, ProcessBasicInformation,
            &pbi, sizeof(pbi), &retLen) != 0) return;

        // Read BeingDebugged flag from PEB
        uint8_t beingDebugged;
        SIZE_T bytesRead;
        // PEB.BeingDebugged is at offset 0x2
        void* pebAddr = (uint8_t*)pbi.PebBaseAddress + 0x2;
        if (ReadProcessMemory(hProcess, pebAddr, &beingDebugged, 1, &bytesRead)) {
            if (beingDebugged) {
                result.Alerts.push_back(Alert(
                    Severity::INFO,
                    DetectionCategory::ANTIDEBUG_PEB,
                    "PEB.BeingDebugged flag is set",
                    "Process is being debugged (PEB flag)"
                ));
                // This is informational, not a detection
            }
        }
    }

    void CheckNtGlobalFlag(HANDLE hProcess, ModuleResult& result) {
        result.ChecksRun++;

        typedef NTSTATUS (WINAPI *pNtQIP)(HANDLE, PROCESSINFOCLASS, PVOID, ULONG, PULONG);
        static auto NtQueryInformationProcess = (pNtQIP)GetProcAddress(
            GetModuleHandleA("ntdll.dll"), "NtQueryInformationProcess");
        if (!NtQueryInformationProcess) return;

        PROCESS_BASIC_INFORMATION pbi = {};
        ULONG retLen;
        if (NtQueryInformationProcess(hProcess, ProcessBasicInformation,
            &pbi, sizeof(pbi), &retLen) != 0) return;

        // NtGlobalFlag is at PEB offset 0xBC (x64)
        uint32_t ntGlobalFlag = 0;
        SIZE_T bytesRead;
        void* flagAddr = (uint8_t*)pbi.PebBaseAddress + 0xBC;
        if (ReadProcessMemory(hProcess, flagAddr, &ntGlobalFlag, sizeof(ntGlobalFlag), &bytesRead)) {
            // FLG_HEAP_ENABLE_TAIL_CHECK | FLG_HEAP_ENABLE_FREE_CHECK | FLG_HEAP_VALIDATE_PARAMETERS
            // = 0x70 when debugger attached
            if (ntGlobalFlag & 0x70) {
                result.Alerts.push_back(Alert(
                    Severity::LOW,
                    DetectionCategory::ANTIDEBUG_PEB,
                    "NtGlobalFlag indicates debugger (heap debug flags set)",
                    "Process may have been started under a debugger"
                ));
                result.DetectionsFound++;
            }
        }
    }

    void CheckHeapFlags(HANDLE hProcess, ModuleResult& result) {
        result.ChecksRun++;
        // Check process heap flags for debugger indicators
        // This is informational for the lab - shows what anti-debug checks look for
    }
};

// ============================================================================
// MODULE 10: Call Stack Inspector
// ============================================================================
class CallStackInspector {
public:
    ModuleResult Inspect(HANDLE hProcess, DWORD targetPid) {
        ModuleResult result("Call Stack Inspector");
        auto start = std::chrono::high_resolution_clock::now();

        // Get module ranges
        std::vector<std::pair<uint64_t, uint64_t>> moduleRanges;
        std::map<uint64_t, std::string> moduleNames;

        HMODULE hMods[1024];
        DWORD cbNeeded;
        if (EnumProcessModules(hProcess, hMods, sizeof(hMods), &cbNeeded)) {
            for (unsigned i = 0; i < (cbNeeded / sizeof(HMODULE)); i++) {
                MODULEINFO mi;
                char modName[MAX_PATH];
                if (GetModuleInformation(hProcess, hMods[i], &mi, sizeof(mi)) &&
                    GetModuleFileNameExA(hProcess, hMods[i], modName, MAX_PATH)) {
                    uint64_t base = (uint64_t)mi.lpBaseOfDll;
                    moduleRanges.push_back({base, base + mi.SizeOfImage});
                    moduleNames[base] = modName;
                }
            }
        }

        // If module enumeration failed, skip call stack validation
        if (moduleRanges.empty()) {
            result.ChecksRun++;
            auto end = std::chrono::high_resolution_clock::now();
            result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
            return result;
        }

        // Walk threads and check call stacks
        HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
        if (hSnap == INVALID_HANDLE_VALUE) {
            auto end = std::chrono::high_resolution_clock::now();
            result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
            return result;
        }

        THREADENTRY32 te;
        te.dwSize = sizeof(te);
        if (Thread32First(hSnap, &te)) {
            do {
                if (te.th32OwnerProcessID != targetPid) continue;
                result.ChecksRun++;

                HANDLE hThread = OpenThread(
                    THREAD_GET_CONTEXT | THREAD_SUSPEND_RESUME |
                    THREAD_QUERY_INFORMATION,
                    FALSE, te.th32ThreadID);
                if (!hThread) continue;

                // Suspend thread to get consistent stack
                SuspendThread(hThread);

                CONTEXT ctx = {};
                ctx.ContextFlags = CONTEXT_FULL;
                if (GetThreadContext(hThread, &ctx)) {
                    // Walk the stack
#ifdef _WIN64
                    uint64_t rip = ctx.Rip;
                    uint64_t rsp = ctx.Rsp;
                    uint64_t rbp = ctx.Rbp;
#else
                    uint64_t rip = ctx.Eip;
                    uint64_t rsp = ctx.Esp;
                    uint64_t rbp = ctx.Ebp;
#endif

                    // Check current RIP
                    bool ripBacked = false;
                    for (auto& range : moduleRanges) {
                        if (rip >= range.first && rip < range.second) {
                            ripBacked = true;
                            break;
                        }
                    }

                    if (!ripBacked && rip != 0) {
                        char detail[256];
                        snprintf(detail, sizeof(detail),
                            "Thread %lu RIP=0x%llX is not within any loaded module",
                            te.th32ThreadID, (unsigned long long)rip);

                        result.Alerts.push_back(Alert(
                            Severity::CRITICAL,
                            DetectionCategory::CALLSTACK_UNBACKED,
                            "Thread executing from unbacked memory",
                            detail, rip, te.th32ThreadID
                        ));
                        result.DetectionsFound++;
                    }

                    // Read stack frames (return addresses)
                    uint64_t stackAddrs[32];
                    SIZE_T bytesRead;
                    if (ReadProcessMemory(hProcess, (void*)rsp, stackAddrs,
                        sizeof(stackAddrs), &bytesRead)) {

                        int frameCount = (int)(bytesRead / sizeof(uint64_t));
                        int unbackedFrames = 0;

                        for (int f = 0; f < frameCount; f++) {
                            if (stackAddrs[f] == 0) continue;

                            bool frameBacked = false;
                            for (auto& range : moduleRanges) {
                                if (stackAddrs[f] >= range.first &&
                                    stackAddrs[f] < range.second) {
                                    frameBacked = true;
                                    break;
                                }
                            }

                            // Only flag if it looks like a code address (high bits set for kernel)
                            if (!frameBacked &&
                                stackAddrs[f] > 0x10000 &&
                                stackAddrs[f] < 0x7FFFFFFFFFFF) {

                                // Verify it's actually executable
                                MEMORY_BASIC_INFORMATION mbi;
                                if (VirtualQueryEx(hProcess, (void*)stackAddrs[f],
                                    &mbi, sizeof(mbi))) {
                                    if (mbi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ |
                                        PAGE_EXECUTE_READWRITE)) {
                                        unbackedFrames++;
                                    }
                                }
                            }
                        }

                        if (unbackedFrames > 0) {
                            char detail[256];
                            snprintf(detail, sizeof(detail),
                                "Thread %lu has %d unbacked return addresses on stack",
                                te.th32ThreadID, unbackedFrames);

                            result.Alerts.push_back(Alert(
                                Severity::HIGH,
                                DetectionCategory::CALLSTACK_UNBACKED,
                                "Suspicious return addresses on call stack",
                                detail, 0, te.th32ThreadID
                            ));
                            result.DetectionsFound++;
                        }
                    }
                }

                ResumeThread(hThread);
                CloseHandle(hThread);
            } while (Thread32Next(hSnap, &te));
        }
        CloseHandle(hSnap);

        auto end = std::chrono::high_resolution_clock::now();
        result.ScanTimeMs = std::chrono::duration<double, std::milli>(end - start).count();
        return result;
    }
};

} // namespace EDR

#endif // EDR_DETECTIONS_HPP
