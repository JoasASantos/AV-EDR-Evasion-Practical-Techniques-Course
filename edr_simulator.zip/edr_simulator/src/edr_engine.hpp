#pragma once
// =============================================================================
// EDR Simulator - Main Engine
// =============================================================================
// Orchestrates all detection modules, manages scanning lifecycle,
// and produces consolidated reports. Supports single-scan and continuous
// monitoring modes.
// =============================================================================

#ifndef EDR_ENGINE_HPP
#define EDR_ENGINE_HPP

#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <string>
#include <vector>
#include <functional>
#include <chrono>
#include <thread>

#include "colors.hpp"
#include "telemetry.hpp"
#include "detections.hpp"

namespace EDR {

// Engine configuration
struct EngineConfig {
    bool EnableMemoryScanner;
    bool EnableNtdllChecker;
    bool EnableEtwMonitor;
    bool EnableAmsiMonitor;
    bool EnableThreadAnalyzer;
    bool EnableModuleInspector;
    bool EnableSyscallDetector;
    bool EnableBehaviorMonitor;
    bool EnableAntiDebugDetector;
    bool EnableCallStackInspector;

    bool ContinuousMode;
    int  ScanIntervalMs;
    int  MaxScans;
    bool ExportReport;
    std::string ReportPath;
    bool Verbose;

    EngineConfig() :
        EnableMemoryScanner(true),
        EnableNtdllChecker(true),
        EnableEtwMonitor(true),
        EnableAmsiMonitor(true),
        EnableThreadAnalyzer(true),
        EnableModuleInspector(true),
        EnableSyscallDetector(true),
        EnableBehaviorMonitor(true),
        EnableAntiDebugDetector(true),
        EnableCallStackInspector(true),
        ContinuousMode(false),
        ScanIntervalMs(5000),
        MaxScans(0),
        ExportReport(false),
        ReportPath("edr_report.txt"),
        Verbose(false)
    {}

    // Preset: Only run specific modules
    void SetModulesFromString(const std::string& modules) {
        // Disable all first
        EnableMemoryScanner = false;
        EnableNtdllChecker = false;
        EnableEtwMonitor = false;
        EnableAmsiMonitor = false;
        EnableThreadAnalyzer = false;
        EnableModuleInspector = false;
        EnableSyscallDetector = false;
        EnableBehaviorMonitor = false;
        EnableAntiDebugDetector = false;
        EnableCallStackInspector = false;

        // Enable requested modules
        bool all = (modules.find("all") != std::string::npos);
        if (modules.find("memory") != std::string::npos || all)
            EnableMemoryScanner = true;
        if (modules.find("ntdll") != std::string::npos || all)
            EnableNtdllChecker = true;
        if (modules.find("etw") != std::string::npos || all)
            EnableEtwMonitor = true;
        if (modules.find("amsi") != std::string::npos || all)
            EnableAmsiMonitor = true;
        if (modules.find("thread") != std::string::npos || all)
            EnableThreadAnalyzer = true;
        if (modules.find("module") != std::string::npos || all)
            EnableModuleInspector = true;
        if (modules.find("syscall") != std::string::npos || all)
            EnableSyscallDetector = true;
        if (modules.find("behavior") != std::string::npos || all)
            EnableBehaviorMonitor = true;
        if (modules.find("antidebug") != std::string::npos || all)
            EnableAntiDebugDetector = true;
        if (modules.find("callstack") != std::string::npos || all)
            EnableCallStackInspector = true;
    }
};

// Find process by name, return PID (0 if not found)
inline DWORD FindProcessByName(const std::string& name) {
    HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (hSnap == INVALID_HANDLE_VALUE) return 0;

    PROCESSENTRY32 pe;
    pe.dwSize = sizeof(pe);
    DWORD pid = 0;

    // Convert search name to lowercase for comparison
    std::string searchName = name;
    for (auto& c : searchName) c = (char)tolower(c);

    if (Process32First(hSnap, &pe)) {
        do {
            // Convert process name (wide) to narrow string
            char narrowName[MAX_PATH];
            wcstombs(narrowName, pe.szExeFile, MAX_PATH);
            std::string procName(narrowName);
            for (auto& c : procName) c = (char)tolower(c);

            if (procName == searchName || procName.find(searchName) != std::string::npos) {
                pid = pe.th32ProcessID;
                break;
            }
        } while (Process32Next(hSnap, &pe));
    }
    CloseHandle(hSnap);
    return pid;
}

// Main EDR Engine
class Engine {
public:
    Engine(const EngineConfig& config) : m_config(config), m_running(false) {}

    // Run single scan
    ScanReport RunScan(DWORD pid, const std::string& processName) {
        ScanReport report;
        report.TargetPID = pid;
        report.TargetProcess = processName;
        report.ScanStart = time(nullptr);
        report.ScanNumber = ++m_telemetry.ScanCount;

        // Open target process
        HANDLE hProcess = OpenProcess(
            PROCESS_QUERY_INFORMATION | PROCESS_VM_READ |
            PROCESS_VM_OPERATION,
            FALSE, pid);

        if (!hProcess) {
            PrintColored(Color::Red,
                "\n  [ERROR] Failed to open process PID %lu (Error: %lu)\n",
                pid, GetLastError());
            PrintColored(Color::Yellow,
                "  [TIP] Try running EDR Simulator as Administrator\n");
            return report;
        }

        PrintSection("SCANNING TARGET");
        char buf[256];
        snprintf(buf, sizeof(buf), "Process: %s (PID: %lu)", processName.c_str(), pid);
        PrintInfo(buf);
        printf("\n");

        int moduleIdx = 0;
        int totalModules = CountEnabledModules();

        // Run detection modules
        if (m_config.EnableMemoryScanner) {
            PrintProgressBar("Scanning...", ++moduleIdx, totalModules);
            MemoryScanner scanner;
            auto result = scanner.Scan(hProcess, pid);
            report.ModuleResults.push_back(result);
        }

        if (m_config.EnableNtdllChecker) {
            PrintProgressBar("Scanning...", ++moduleIdx, totalModules);
            NtdllIntegrityChecker checker;
            auto result = checker.Check(hProcess);
            report.ModuleResults.push_back(result);
        }

        if (m_config.EnableEtwMonitor) {
            PrintProgressBar("Scanning...", ++moduleIdx, totalModules);
            EtwMonitor monitor;
            auto result = monitor.Check(hProcess);
            report.ModuleResults.push_back(result);
        }

        if (m_config.EnableAmsiMonitor) {
            PrintProgressBar("Scanning...", ++moduleIdx, totalModules);
            AmsiMonitor monitor;
            auto result = monitor.Check(hProcess);
            report.ModuleResults.push_back(result);
        }

        if (m_config.EnableThreadAnalyzer) {
            PrintProgressBar("Scanning...", ++moduleIdx, totalModules);
            ThreadAnalyzer analyzer;
            auto result = analyzer.Analyze(hProcess, pid);
            report.ModuleResults.push_back(result);
        }

        if (m_config.EnableModuleInspector) {
            PrintProgressBar("Scanning...", ++moduleIdx, totalModules);
            ModuleInspector inspector;
            auto result = inspector.Inspect(hProcess);
            report.ModuleResults.push_back(result);
        }

        if (m_config.EnableSyscallDetector) {
            PrintProgressBar("Scanning...", ++moduleIdx, totalModules);
            SyscallDetector detector;
            auto result = detector.Detect(hProcess);
            report.ModuleResults.push_back(result);
        }

        if (m_config.EnableBehaviorMonitor) {
            PrintProgressBar("Scanning...", ++moduleIdx, totalModules);
            BehaviorMonitor monitor;
            auto result = monitor.Monitor(hProcess, pid);
            report.ModuleResults.push_back(result);
        }

        if (m_config.EnableAntiDebugDetector) {
            PrintProgressBar("Scanning...", ++moduleIdx, totalModules);
            AntiDebugDetector detector;
            auto result = detector.Detect(hProcess, pid);
            report.ModuleResults.push_back(result);
        }

        if (m_config.EnableCallStackInspector) {
            PrintProgressBar("Scanning...", ++moduleIdx, totalModules);
            CallStackInspector inspector;
            auto result = inspector.Inspect(hProcess, pid);
            report.ModuleResults.push_back(result);
        }

        CloseHandle(hProcess);

        report.ScanEnd = time(nullptr);
        m_telemetry.AddReport(report);

        return report;
    }

    // Run continuous monitoring
    void RunContinuous(DWORD pid, const std::string& processName) {
        m_running = true;

        PrintColored(Color::Yellow,
            "\n  [*] Starting continuous monitoring (interval: %dms)\n",
            m_config.ScanIntervalMs);
        PrintColored(Color::Yellow,
            "  [*] Press Ctrl+C to stop\n\n");

        int scanCount = 0;
        while (m_running) {
            // Check if process still exists
            HANDLE hCheck = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pid);
            if (!hCheck) {
                PrintColored(Color::Red,
                    "\n  [!] Target process (PID %lu) has terminated\n", pid);
                break;
            }
            CloseHandle(hCheck);

            auto report = RunScan(pid, processName);
            report.Print();
            scanCount++;

            if (m_config.MaxScans > 0 && scanCount >= m_config.MaxScans) {
                PrintColored(Color::Yellow,
                    "\n  [*] Maximum scan count (%d) reached\n", m_config.MaxScans);
                break;
            }

            // Wait for next scan
            if (m_running) {
                PrintColored(Color::DarkCyan,
                    "\n  [*] Next scan in %d seconds...\n",
                    m_config.ScanIntervalMs / 1000);

                // Sleep in small increments so we can respond to stop
                int waited = 0;
                while (waited < m_config.ScanIntervalMs && m_running) {
                    Sleep(100);
                    waited += 100;
                }
            }
        }

        // Print trend if multiple scans
        m_telemetry.PrintTrend();

        // Export final report
        if (m_config.ExportReport) {
            if (!m_telemetry.Reports.empty()) {
                m_telemetry.Reports.back().ExportToFile(m_config.ReportPath);
                char buf[256];
                snprintf(buf, sizeof(buf), "Report exported to: %s",
                    m_config.ReportPath.c_str());
                PrintOK(buf);
            }
        }
    }

    void Stop() { m_running = false; }

    TelemetryCollector& GetTelemetry() { return m_telemetry; }

private:
    int CountEnabledModules() {
        int count = 0;
        if (m_config.EnableMemoryScanner) count++;
        if (m_config.EnableNtdllChecker) count++;
        if (m_config.EnableEtwMonitor) count++;
        if (m_config.EnableAmsiMonitor) count++;
        if (m_config.EnableThreadAnalyzer) count++;
        if (m_config.EnableModuleInspector) count++;
        if (m_config.EnableSyscallDetector) count++;
        if (m_config.EnableBehaviorMonitor) count++;
        if (m_config.EnableAntiDebugDetector) count++;
        if (m_config.EnableCallStackInspector) count++;
        return count;
    }

    EngineConfig       m_config;
    TelemetryCollector m_telemetry;
    bool               m_running;
};

} // namespace EDR

#endif // EDR_ENGINE_HPP
