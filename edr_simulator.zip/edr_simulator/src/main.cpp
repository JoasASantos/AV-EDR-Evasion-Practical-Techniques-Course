// =============================================================================
// EDR Simulator v2.0 - Evasion Training Platform
// =============================================================================
// A comprehensive EDR (Endpoint Detection & Response) simulator designed for
// offensive security training. Monitors a target process for evasion techniques
// and generates detailed detection reports with scoring.
//
// COMPILATION:
//   cl /EHsc /std:c++17 /O2 main.cpp /Fe:edr_sim.exe /link psapi.lib dbghelp.lib advapi32.lib
//
// USAGE:
//   edr_sim.exe <process_name|PID|path_to_exe> [options]
//
// OPTIONS:
//   -s, --scan <target>     Scan a specific process (name, PID, or exe path)
//   -c, --continuous        Continuous monitoring mode
//   -i, --interval <ms>     Scan interval in milliseconds (default: 5000)
//   -n, --max-scans <n>     Maximum number of scans (0 = unlimited)
//   -m, --modules <list>    Comma-separated modules to enable (default: all)
//   -o, --output <file>     Export report to file
//   -v, --verbose           Verbose output
//   -h, --help              Show this help
//
// MODULES:
//   memory    - Memory scanner (RWX, shellcode, unbacked)
//   ntdll     - NTDLL integrity checker (hook detection)
//   etw       - ETW patch monitor
//   amsi      - AMSI patch monitor
//   thread    - Thread analyzer (injection, suspicious starts)
//   module    - Module inspector (stomping, unsigned)
//   syscall   - Direct syscall detector
//   behavior  - Behavior monitor (child procs, privileges)
//   antidebug - Anti-debug detector (PEB, timing, HWBP)
//   callstack - Call stack inspector (unbacked returns)
//   all       - Enable all modules (default)
//
// EXAMPLES:
//   edr_sim.exe notepad.exe
//   edr_sim.exe 1234 -c -i 3000
//   edr_sim.exe target.exe -m memory,ntdll,syscall
//   edr_sim.exe payload.exe -c -o report.txt
//   edr_sim.exe C:\path\to\loader.exe            (auto-launch + scan)
//
// FOR EDUCATIONAL USE ONLY - Authorized security training and research
// =============================================================================

#include <windows.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <signal.h>

#include "edr_engine.hpp"

// Global engine pointer for signal handling
static EDR::Engine* g_pEngine = nullptr;

void SignalHandler(int sig) {
    if (sig == SIGINT || sig == SIGBREAK) {
        printf("\n");
        EDR::PrintColored(EDR::Color::Yellow,
            "\n  [*] Received stop signal, finishing current scan...\n");
        if (g_pEngine) g_pEngine->Stop();
    }
}

void PrintUsage(const char* progName) {
    EDR::PrintBanner();
    printf("\n  USAGE: %s <process_name|PID|path_to_exe> [options]\n\n", progName);

    printf("  OPTIONS:\n");
    printf("    -s, --scan <target>     Scan a specific process (name, PID, or exe path)\n");
    printf("    -c, --continuous        Continuous monitoring mode\n");
    printf("    -i, --interval <ms>     Scan interval (default: 5000ms)\n");
    printf("    -n, --max-scans <n>     Max scans (0 = unlimited)\n");
    printf("    -m, --modules <list>    Modules to enable (comma-separated)\n");
    printf("    -o, --output <file>     Export report to file\n");
    printf("    -v, --verbose           Verbose output\n");
    printf("    -h, --help              Show this help\n");

    printf("\n  MODULES:\n");
    printf("    memory     Memory scanner (RWX pages, shellcode signatures)\n");
    printf("    ntdll      NTDLL integrity (hook detection)\n");
    printf("    etw        ETW function patch monitor\n");
    printf("    amsi       AMSI function patch monitor\n");
    printf("    thread     Thread analyzer (injection detection)\n");
    printf("    module     Module inspector (stomping detection)\n");
    printf("    syscall    Direct syscall detector\n");
    printf("    behavior   Behavior monitor (child processes, tokens)\n");
    printf("    antidebug  Anti-debug detector (PEB, HWBP)\n");
    printf("    callstack  Call stack inspector (return address validation)\n");
    printf("    all        Enable all modules (default)\n");

    printf("\n  EXAMPLES:\n");
    EDR::SetColor(EDR::Color::Green);
    printf("    %s notepad.exe                    ", progName);
    EDR::ResetColor();
    printf("  Single scan\n");
    EDR::SetColor(EDR::Color::Green);
    printf("    %s 1234 -c -i 3000                ", progName);
    EDR::ResetColor();
    printf("  Monitor PID every 3s\n");
    EDR::SetColor(EDR::Color::Green);
    printf("    %s target.exe -m memory,syscall   ", progName);
    EDR::ResetColor();
    printf("  Specific modules\n");
    EDR::SetColor(EDR::Color::Green);
    printf("    %s payload.exe -c -n 10 -o rpt.txt", progName);
    EDR::ResetColor();
    printf("  10 scans + report\n");
    EDR::SetColor(EDR::Color::Green);
    printf("    %s C:\\path\\to\\loader.exe            ", progName);
    EDR::ResetColor();
    printf("  Auto-launch + scan\n");

    printf("\n  DETECTION CATEGORIES:\n");
    printf("    ┌────────────────────────┬──────────────────────────────────┐\n");
    printf("    │ Category               │ What It Detects                  │\n");
    printf("    ├────────────────────────┼──────────────────────────────────┤\n");
    printf("    │ MEMORY:RWX_PAGE        │ Read-Write-Execute memory pages  │\n");
    printf("    │ MEMORY:SHELLCODE       │ Known shellcode byte patterns    │\n");
    printf("    │ MEMORY:UNBACKED_EXEC   │ Executable memory without file   │\n");
    printf("    │ INTEGRITY:NTDLL_PATCH  │ Hooked ntdll.dll functions       │\n");
    printf("    │ INTEGRITY:ETW_PATCH    │ Patched ETW telemetry functions  │\n");
    printf("    │ INTEGRITY:AMSI_PATCH   │ Patched AMSI scan functions      │\n");
    printf("    │ THREAD:SUSPICIOUS      │ Threads with unbacked start addr │\n");
    printf("    │ MODULE:STOMPING        │ Module .text section overwritten │\n");
    printf("    │ SYSCALL:DIRECT         │ Syscall instructions outside OS  │\n");
    printf("    │ SYSCALL:STUB           │ Syscall stubs in user memory     │\n");
    printf("    │ STACK:UNBACKED         │ Return addresses to unknown mem  │\n");
    printf("    │ ANTIDEBUG:PEB          │ PEB debug flag manipulation      │\n");
    printf("    │ ANTIDEBUG:HWBP         │ Hardware breakpoint usage        │\n");
    printf("    │ BEHAVIOR:SUSPICIOUS    │ Process behavior anomalies       │\n");
    printf("    └────────────────────────┴──────────────────────────────────┘\n");

    printf("\n  SCORING:\n");
    printf("    Evasion Rate = (Total Checks - Detections) / Total Checks * 100%%\n");
    printf("    GHOST MODE (90%%+) | ADVANCED (75%%+) | INTERMEDIATE (50%%+)\n");
    printf("    BEGINNER (25%%+)   | DETECTED (<25%%)\n");

    printf("\n  FOR EDUCATIONAL AND AUTHORIZED SECURITY RESEARCH USE ONLY\n\n");
}

int main(int argc, char* argv[]) {
    // Enable UTF-8 output
    SetConsoleOutputCP(CP_UTF8);

    if (argc < 2) {
        PrintUsage(argv[0]);
        return 1;
    }

    // Parse arguments
    std::string target;
    EDR::EngineConfig config;
    bool showHelp = false;

    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];

        if (arg == "-h" || arg == "--help") {
            showHelp = true;
        } else if (arg == "-c" || arg == "--continuous") {
            config.ContinuousMode = true;
        } else if ((arg == "-i" || arg == "--interval") && i + 1 < argc) {
            config.ScanIntervalMs = atoi(argv[++i]);
        } else if ((arg == "-n" || arg == "--max-scans") && i + 1 < argc) {
            config.MaxScans = atoi(argv[++i]);
        } else if ((arg == "-m" || arg == "--modules") && i + 1 < argc) {
            config.SetModulesFromString(argv[++i]);
        } else if ((arg == "-o" || arg == "--output") && i + 1 < argc) {
            config.ExportReport = true;
            config.ReportPath = argv[++i];
        } else if (arg == "-v" || arg == "--verbose") {
            config.Verbose = true;
        } else if ((arg == "-s" || arg == "--scan") && i + 1 < argc) {
            target = argv[++i];
        } else if (arg[0] != '-') {
            target = arg;
        }
    }

    if (showHelp) {
        PrintUsage(argv[0]);
        return 0;
    }

    if (target.empty()) {
        EDR::PrintColored(EDR::Color::Red, "\n  [ERROR] No target specified\n\n");
        return 1;
    }

    EDR::PrintBanner();

    // Resolve target to PID
    DWORD targetPid = 0;
    std::string processName;
    HANDLE hLaunchedProcess = NULL;  // Track if we launched the process

    // Check if target is a PID (all digits)
    bool isPid = true;
    for (char c : target) {
        if (!isdigit(c)) { isPid = false; break; }
    }

    // Check if target is a file path (contains \ or / and ends with .exe)
    bool isFilePath = false;
    if (!isPid) {
        if (target.find('\\') != std::string::npos ||
            target.find('/') != std::string::npos) {
            isFilePath = true;
        }
    }

    if (isPid) {
        targetPid = (DWORD)atoi(target.c_str());
        // Get process name from PID
        HANDLE hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if (hSnap != INVALID_HANDLE_VALUE) {
            PROCESSENTRY32 pe;
            pe.dwSize = sizeof(pe);
            if (Process32First(hSnap, &pe)) {
                do {
                    if (pe.th32ProcessID == targetPid) {
                        char narrowName[MAX_PATH];
                        wcstombs(narrowName, pe.szExeFile, MAX_PATH);
                        processName = narrowName;
                        break;
                    }
                } while (Process32Next(hSnap, &pe));
            }
            CloseHandle(hSnap);
        }
        if (processName.empty()) processName = target;
    } else if (isFilePath) {
        // Target is a file path - extract filename
        std::string filename = target;
        size_t lastSlash = target.find_last_of("\\/");
        if (lastSlash != std::string::npos) {
            filename = target.substr(lastSlash + 1);
        }
        processName = filename;

        // First, check if it's already running
        targetPid = EDR::FindProcessByName(filename);

        if (targetPid == 0) {
            // Check if the file exists
            DWORD fileAttrib = GetFileAttributesA(target.c_str());
            if (fileAttrib == INVALID_FILE_ATTRIBUTES) {
                EDR::PrintColored(EDR::Color::Red,
                    "\n  [ERROR] File not found: %s\n\n", target.c_str());
                return 1;
            }

            // Launch the process
            EDR::PrintColored(EDR::Color::Cyan,
                "\n  [*] Launching: %s\n", target.c_str());

            STARTUPINFOA si = {};
            si.cb = sizeof(si);
            PROCESS_INFORMATION pi = {};

            if (!CreateProcessA(
                    target.c_str(),    // Application path
                    NULL,              // Command line
                    NULL, NULL,        // Security attributes
                    FALSE,             // Inherit handles
                    CREATE_SUSPENDED,  // Start suspended for clean scan
                    NULL,              // Environment
                    NULL,              // Current directory
                    &si, &pi)) {
                EDR::PrintColored(EDR::Color::Red,
                    "\n  [ERROR] Failed to launch process (Error: %lu)\n",
                    GetLastError());
                EDR::PrintColored(EDR::Color::Yellow,
                    "  [TIP] Check if the file is a valid executable\n\n");
                return 1;
            }

            targetPid = pi.dwProcessId;
            hLaunchedProcess = pi.hProcess;

            // Resume and wait for initialization
            ResumeThread(pi.hThread);
            CloseHandle(pi.hThread);

            EDR::PrintColored(EDR::Color::Green,
                "  [+] Process launched (PID: %lu)\n", targetPid);
            EDR::PrintColored(EDR::Color::Cyan,
                "  [*] Waiting 2s for initialization...\n");
            Sleep(2000);
        }
    } else {
        processName = target;
        targetPid = EDR::FindProcessByName(target);
    }

    if (targetPid == 0) {
        EDR::PrintColored(EDR::Color::Red,
            "\n  [ERROR] Process '%s' not found\n", target.c_str());
        EDR::PrintColored(EDR::Color::Yellow,
            "  [TIP] Make sure the process is running before scanning\n");
        EDR::PrintColored(EDR::Color::Yellow,
            "  [TIP] You can use: process name, PID, or full path to .exe\n\n");
        return 1;
    }

    // Print configuration
    EDR::PrintSection("CONFIGURATION");
    char buf[256];
    snprintf(buf, sizeof(buf), "Target: %s (PID: %lu)", processName.c_str(), targetPid);
    EDR::PrintInfo(buf);
    snprintf(buf, sizeof(buf), "Mode: %s",
        config.ContinuousMode ? "Continuous Monitoring" : "Single Scan");
    EDR::PrintInfo(buf);

    if (config.ContinuousMode) {
        snprintf(buf, sizeof(buf), "Interval: %dms", config.ScanIntervalMs);
        EDR::PrintInfo(buf);
    }

    // List enabled modules
    printf("\n");
    EDR::PrintSubSection("Enabled Detection Modules:");
    if (config.EnableMemoryScanner)     EDR::PrintOK("Memory Scanner");
    if (config.EnableNtdllChecker)      EDR::PrintOK("NTDLL Integrity Checker");
    if (config.EnableEtwMonitor)        EDR::PrintOK("ETW Monitor");
    if (config.EnableAmsiMonitor)       EDR::PrintOK("AMSI Monitor");
    if (config.EnableThreadAnalyzer)    EDR::PrintOK("Thread Analyzer");
    if (config.EnableModuleInspector)   EDR::PrintOK("Module Inspector");
    if (config.EnableSyscallDetector)   EDR::PrintOK("Syscall Detector");
    if (config.EnableBehaviorMonitor)   EDR::PrintOK("Behavior Monitor");
    if (config.EnableAntiDebugDetector) EDR::PrintOK("Anti-Debug Detector");
    if (config.EnableCallStackInspector) EDR::PrintOK("Call Stack Inspector");

    // Create engine
    EDR::Engine engine(config);
    g_pEngine = &engine;

    // Register signal handler
    signal(SIGINT, SignalHandler);
    signal(SIGBREAK, SignalHandler);

    if (config.ContinuousMode) {
        engine.RunContinuous(targetPid, processName);
    } else {
        auto report = engine.RunScan(targetPid, processName);
        report.Print();

        if (config.ExportReport) {
            report.ExportToFile(config.ReportPath);
            char msg[256];
            snprintf(msg, sizeof(msg), "Report exported to: %s",
                config.ReportPath.c_str());
            EDR::PrintOK(msg);
        }
    }

    // If we launched the process, terminate it after scanning
    if (hLaunchedProcess) {
        EDR::PrintColored(EDR::Color::Cyan,
            "\n  [*] Terminating launched process (PID: %lu)...\n", targetPid);
        TerminateProcess(hLaunchedProcess, 0);
        CloseHandle(hLaunchedProcess);
        EDR::PrintColored(EDR::Color::Green,
            "  [+] Process terminated\n");
    }

    g_pEngine = nullptr;
    return 0;
}
