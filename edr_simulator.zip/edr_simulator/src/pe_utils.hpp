#pragma once
// =============================================================================
// EDR Simulator - PE Parsing Utilities
// =============================================================================
// Provides portable PE (Portable Executable) parsing for comparing on-disk
// DLLs with in-memory versions. Used for hook detection and integrity checks.
// =============================================================================

#ifndef EDR_PE_UTILS_HPP
#define EDR_PE_UTILS_HPP

#include <windows.h>
#include <string>
#include <vector>
#include <cstdint>

namespace EDR {

struct SectionInfo {
    char     Name[9];
    uint32_t VirtualAddress;
    uint32_t VirtualSize;
    uint32_t RawOffset;
    uint32_t RawSize;
    uint32_t Characteristics;
};

struct ExportEntry {
    std::string Name;
    uint32_t    RVA;
    uint16_t    Ordinal;
};

struct PEInfo {
    bool                      Valid;
    bool                      Is64Bit;
    uint32_t                  ImageBase;
    uint64_t                  ImageBase64;
    uint32_t                  SizeOfImage;
    uint32_t                  EntryPoint;
    std::vector<SectionInfo>  Sections;
    std::vector<ExportEntry>  Exports;
};

// Parse PE headers from raw file bytes
inline PEInfo ParsePE(const uint8_t* data, size_t size) {
    PEInfo info = {};
    info.Valid = false;

    if (size < sizeof(IMAGE_DOS_HEADER)) return info;

    auto* dos = (IMAGE_DOS_HEADER*)data;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return info;

    if ((size_t)dos->e_lfanew + sizeof(IMAGE_NT_HEADERS64) > size) return info;

    auto* nt32 = (IMAGE_NT_HEADERS32*)(data + dos->e_lfanew);
    auto* nt64 = (IMAGE_NT_HEADERS64*)(data + dos->e_lfanew);

    if (nt32->Signature != IMAGE_NT_SIGNATURE) return info;

    info.Is64Bit = (nt32->FileHeader.Machine == IMAGE_FILE_MACHINE_AMD64);

    if (info.Is64Bit) {
        info.ImageBase64 = nt64->OptionalHeader.ImageBase;
        info.ImageBase   = (uint32_t)nt64->OptionalHeader.ImageBase;
        info.SizeOfImage = nt64->OptionalHeader.SizeOfImage;
        info.EntryPoint  = nt64->OptionalHeader.AddressOfEntryPoint;
    } else {
        info.ImageBase   = nt32->OptionalHeader.ImageBase;
        info.ImageBase64 = nt32->OptionalHeader.ImageBase;
        info.SizeOfImage = nt32->OptionalHeader.SizeOfImage;
        info.EntryPoint  = nt32->OptionalHeader.AddressOfEntryPoint;
    }

    // Parse sections
    WORD numSections = nt32->FileHeader.NumberOfSections;
    IMAGE_SECTION_HEADER* sections;

    if (info.Is64Bit) {
        sections = (IMAGE_SECTION_HEADER*)((uint8_t*)nt64 +
            sizeof(IMAGE_NT_HEADERS64));
    } else {
        sections = (IMAGE_SECTION_HEADER*)((uint8_t*)nt32 +
            sizeof(IMAGE_NT_HEADERS32));
    }

    for (WORD i = 0; i < numSections; i++) {
        SectionInfo sec = {};
        memcpy(sec.Name, sections[i].Name, 8);
        sec.Name[8] = '\0';
        sec.VirtualAddress  = sections[i].VirtualAddress;
        sec.VirtualSize     = sections[i].Misc.VirtualSize;
        sec.RawOffset       = sections[i].PointerToRawData;
        sec.RawSize         = sections[i].SizeOfRawData;
        sec.Characteristics = sections[i].Characteristics;
        info.Sections.push_back(sec);
    }

    // Parse exports
    IMAGE_DATA_DIRECTORY exportDir;
    if (info.Is64Bit) {
        exportDir = nt64->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
    } else {
        exportDir = nt32->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
    }

    if (exportDir.VirtualAddress != 0 && exportDir.Size != 0) {
        // Need to convert RVA to file offset using sections
        uint32_t exportRVA = exportDir.VirtualAddress;

        // Find section containing export directory
        for (auto& sec : info.Sections) {
            if (exportRVA >= sec.VirtualAddress &&
                exportRVA < sec.VirtualAddress + sec.VirtualSize) {

                uint32_t offset = sec.RawOffset + (exportRVA - sec.VirtualAddress);
                if (offset + sizeof(IMAGE_EXPORT_DIRECTORY) > size) break;

                auto* expDir = (IMAGE_EXPORT_DIRECTORY*)(data + offset);
                uint32_t nameCount = expDir->NumberOfNames;

                // Get arrays
                uint32_t namesOffset = sec.RawOffset +
                    (expDir->AddressOfNames - sec.VirtualAddress);
                uint32_t funcsOffset = sec.RawOffset +
                    (expDir->AddressOfFunctions - sec.VirtualAddress);
                uint32_t ordsOffset = sec.RawOffset +
                    (expDir->AddressOfNameOrdinals - sec.VirtualAddress);

                if (namesOffset + nameCount * 4 > size) break;
                if (funcsOffset + expDir->NumberOfFunctions * 4 > size) break;
                if (ordsOffset + nameCount * 2 > size) break;

                auto* names = (uint32_t*)(data + namesOffset);
                auto* funcs = (uint32_t*)(data + funcsOffset);
                auto* ords  = (uint16_t*)(data + ordsOffset);

                for (uint32_t j = 0; j < nameCount && j < 4096; j++) {
                    uint32_t nameOff = sec.RawOffset +
                        (names[j] - sec.VirtualAddress);
                    if (nameOff >= size) continue;

                    ExportEntry entry;
                    entry.Name    = (const char*)(data + nameOff);
                    entry.Ordinal = ords[j];
                    entry.RVA     = funcs[ords[j]];
                    info.Exports.push_back(entry);
                }
                break;
            }
        }
    }

    info.Valid = true;
    return info;
}

// Read a file into a byte vector
inline std::vector<uint8_t> ReadFileBytes(const std::string& path) {
    std::vector<uint8_t> data;
    HANDLE hFile = CreateFileA(path.c_str(), GENERIC_READ, FILE_SHARE_READ,
        NULL, OPEN_EXISTING, 0, NULL);
    if (hFile == INVALID_HANDLE_VALUE) return data;

    DWORD fileSize = GetFileSize(hFile, NULL);
    if (fileSize == INVALID_FILE_SIZE || fileSize == 0) {
        CloseHandle(hFile);
        return data;
    }

    data.resize(fileSize);
    DWORD bytesRead;
    if (!ReadFile(hFile, data.data(), fileSize, &bytesRead, NULL)) {
        data.clear();
    }
    CloseHandle(hFile);
    return data;
}

// Get the .text section from a PE
inline bool GetTextSection(const PEInfo& pe, const uint8_t* data,
                           const uint8_t** outData, uint32_t* outSize,
                           uint32_t* outRVA) {
    for (auto& sec : pe.Sections) {
        if (strcmp(sec.Name, ".text") == 0) {
            *outData = data + sec.RawOffset;
            *outSize = sec.RawSize;
            *outRVA  = sec.VirtualAddress;
            return true;
        }
    }
    return false;
}

// Find export by name
inline const ExportEntry* FindExport(const PEInfo& pe, const char* name) {
    for (auto& exp : pe.Exports) {
        if (exp.Name == name) return &exp;
    }
    return nullptr;
}

// Convert RVA to file offset
inline uint32_t RvaToOffset(const PEInfo& pe, uint32_t rva) {
    for (auto& sec : pe.Sections) {
        if (rva >= sec.VirtualAddress &&
            rva < sec.VirtualAddress + sec.VirtualSize) {
            return sec.RawOffset + (rva - sec.VirtualAddress);
        }
    }
    return 0;
}

} // namespace EDR

#endif // EDR_PE_UTILS_HPP
