@echo off
REM =============================================================================
REM EDR Simulator Build Script
REM =============================================================================
REM Requires: Visual Studio Build Tools (cl.exe in PATH)
REM Run from: Developer Command Prompt for VS
REM =============================================================================

echo.
echo  ====================================
echo   Building EDR Simulator v2.0
echo  ====================================
echo.

REM Check for Visual Studio compiler
where cl >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo  [ERROR] cl.exe not found!
    echo  [TIP]   Run this from "x64 Native Tools Command Prompt for VS"
    echo  [TIP]   Or run: "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat" x64
    exit /b 1
)

REM Check for x64 compiler (required - this tool targets x64 Windows)
cl 2>&1 | findstr /C:"for x64" >nul
if %ERRORLEVEL% NEQ 0 (
    echo  [WARNING] Compiler does not appear to target x64!
    echo  [WARNING] This tool requires x64 compilation.
    echo  [TIP]     Use "x64 Native Tools Command Prompt for VS"
    echo  [TIP]     Or run: vcvarsall.bat x64
    echo.
)

REM Create output directory
if not exist "bin" mkdir bin

echo  [*] Compiling edr_sim.exe ...
cl /EHsc /std:c++17 /O2 /W3 ^
    /DUNICODE /D_UNICODE ^
    /I src ^
    src\main.cpp ^
    /Fe:bin\edr_sim.exe ^
    /Fo:bin\ ^
    /link ^
    psapi.lib ^
    dbghelp.lib ^
    advapi32.lib ^
    shell32.lib

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo  [FAILED] Build failed!
    exit /b 1
)

echo.
echo  [OK] Build successful!
echo  [OK] Output: bin\edr_sim.exe
echo.
echo  USAGE:
echo    bin\edr_sim.exe ^<process_name^|PID^> [options]
echo.
echo  EXAMPLES:
echo    bin\edr_sim.exe notepad.exe
echo    bin\edr_sim.exe 1234 -c -i 3000
echo    bin\edr_sim.exe target.exe -m memory,ntdll,syscall
echo.
