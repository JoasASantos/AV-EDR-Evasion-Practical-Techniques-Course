# EDR Simulator v2.0

## Overview

The EDR Simulator is a training tool that replicates real EDR (Endpoint Detection & Response) detection capabilities. It monitors a target process and generates detailed reports on what evasion techniques were detected.

Your goal as a student is to **build evasion tools that achieve the highest possible evasion score** against this simulator.

## Quick Start

### Build
```batch
# Open Developer Command Prompt for VS
cd edr_simulator
build.bat
```

### Run
```batch
# Single scan
bin\edr_sim.exe notepad.exe

# Continuous monitoring (every 3 seconds)
bin\edr_sim.exe target.exe -c -i 3000

# Specific detection modules only
bin\edr_sim.exe payload.exe -m memory,ntdll,syscall

# Export report
bin\edr_sim.exe payload.exe -c -n 10 -o report.txt
```

## Detection Modules

| # | Module | What It Detects | Lab Exercise |
|---|--------|----------------|--------------|
| 1 | **Memory Scanner** | RWX pages, shellcode signatures, unbacked executable memory | Lab 01, 08, 09 |
| 2 | **NTDLL Integrity** | Hooked/patched ntdll.dll functions (JMP hooks, RET patches) | Lab 03 |
| 3 | **ETW Monitor** | Patched EtwEventWrite, EtwEventRegister, NtTraceEvent | Lab 07 |
| 4 | **AMSI Monitor** | Patched AmsiScanBuffer, AmsiOpenSession, .data corruption | Lab 02 |
| 5 | **Thread Analyzer** | Threads with unbacked start addresses, hardware breakpoints | Lab 05, 14 |
| 6 | **Module Inspector** | Module stomping (.text section overwritten vs on-disk) | Lab 13 |
| 7 | **Syscall Detector** | Direct syscall instructions outside ntdll/win32u | Lab 04, 12 |
| 8 | **Behavior Monitor** | Elevated privileges, suspicious child processes | Lab 06, 11 |
| 9 | **Anti-Debug Detector** | PEB debug flags, NtGlobalFlag, heap flags | Lab 11 |
| 10 | **Call Stack Inspector** | Unbacked return addresses, executing from non-module memory | Lab 14 |

## Scoring System

```
Evasion Rate = (Total Checks - Detections) / Total Checks × 100%

╔═══════════════════════════════════════╗
║  GHOST MODE    ≥ 90%  evasion rate    ║
║  ADVANCED      ≥ 75%  evasion rate    ║
║  INTERMEDIATE  ≥ 50%  evasion rate    ║
║  BEGINNER      ≥ 25%  evasion rate    ║
║  DETECTED      < 25%  evasion rate    ║
╚═══════════════════════════════════════╝
```

## Alert Severity Levels

| Level | Meaning | Example |
|-------|---------|---------|
| **CRITICAL** | Confirmed malicious technique | Direct syscall stub, NTDLL function hooked |
| **HIGH** | Likely malicious activity | RWX memory pages, unbacked executable |
| **MEDIUM** | Suspicious but could be benign | Hardware breakpoints, private exec memory |
| **LOW** | Minor anomaly | Elevated process token |
| **INFO** | Informational only | PEB debug flag status |

## Detection Categories

```
MEMORY:RWX_PAGE         - Read-Write-Execute memory pages
MEMORY:SHELLCODE        - Known shellcode byte patterns
MEMORY:UNBACKED_EXEC    - Executable memory not backed by file
INTEGRITY:NTDLL_PATCH   - Modified ntdll.dll functions
INTEGRITY:ETW_PATCH     - Patched ETW telemetry functions
INTEGRITY:AMSI_PATCH    - Patched AMSI scanning functions
THREAD:SUSPICIOUS       - Threads with unbacked start addresses
MODULE:STOMPING         - Module .text section overwritten
SYSCALL:DIRECT          - Syscall instructions outside ntdll
SYSCALL:STUB            - Complete syscall stubs in user memory
STACK:UNBACKED          - Return addresses to unknown memory
ANTIDEBUG:PEB           - Anti-debug PEB flag manipulation
ANTIDEBUG:HWBP          - Hardware breakpoint usage
BEHAVIOR:SUSPICIOUS     - Process behavior anomalies
```

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    EDR Simulator Engine                       │
├─────────────┬─────────────┬──────────────┬──────────────────┤
│ Memory      │ Integrity   │ Thread       │ Behavioral       │
│ Scanner     │ Checkers    │ Analyzer     │ Monitor          │
│             │             │              │                  │
│ • RWX pages │ • NTDLL     │ • Start addr │ • Child procs    │
│ • Shellcode │ • ETW funcs │ • HW brkpts  │ • Token privs    │
│ • Unbacked  │ • AMSI funcs│ • Injection  │ • Suspicious ops │
├─────────────┼─────────────┼──────────────┼──────────────────┤
│ Module      │ Syscall     │ Call Stack   │ Anti-Debug       │
│ Inspector   │ Detector    │ Inspector    │ Detector         │
│             │             │              │                  │
│ • Stomping  │ • 0F 05     │ • RIP valid  │ • PEB flags      │
│ • .text cmp │ • Stub pat  │ • RBP chain  │ • NtGlobalFlag   │
│ • Unsigned  │ • SSN match │ • Ret addrs  │ • Heap flags     │
└─────────────┴─────────────┴──────────────┴──────────────────┘
                           │
                    ┌──────┴──────┐
                    │  Telemetry  │
                    │  Collector  │
                    ├─────────────┤
                    │ • Alerts    │
                    │ • Scoring   │
                    │ • Reports   │
                    │ • Trends    │
                    └─────────────┘
```

## Workflow

```
1. Student compiles their evasion tool
2. Student launches their tool (or a target process)
3. Student runs: edr_sim.exe <process> -c
4. EDR Simulator scans and reports detections
5. Student modifies their code to evade detections
6. Repeat until achieving GHOST MODE
```

## Command Line Reference

```
edr_sim.exe <target> [options]

Target:
  process_name        Find process by name (e.g., notepad.exe)
  PID                 Target by process ID (e.g., 1234)

Options:
  -s, --scan TARGET   Scan a specific process (name or PID)
  -c, --continuous    Continuous monitoring (scan repeatedly)
  -i, --interval N    Milliseconds between scans (default: 5000)
  -n, --max-scans N   Stop after N scans (0 = unlimited)
  -m, --modules LIST  Enable specific modules (comma-separated)
  -o, --output FILE   Export report to text file
  -v, --verbose       Show additional diagnostic info
  -h, --help          Show help and exit
```

## Requirements

- Windows 10/11 (x64)
- Visual Studio 2019+ Build Tools
- Run as Administrator for full capabilities
- Target process must be running before scanning

## Educational Use Only

This tool is designed for authorized security training, CTF competitions, and defensive research. Unauthorized use against systems without permission is illegal.
